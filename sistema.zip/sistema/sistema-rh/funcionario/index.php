<?php
/**
 * Dashboard do Funcionário
 * Exibe resumo pessoal: ponto do dia, serviços e folha do mês
 */
session_start();
define('BASE_URL', '..');
require_once '../config/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/layout.php';

verificarFuncionario();

$usuario = getUsuarioLogado();
$userId  = $usuario['id'];
$hoje    = date('Y-m-d');
$mes     = date('Y-m');

// ---- Registros de ponto de hoje ----
$stmt = $conn->prepare("
    SELECT tipo, TIME(data_hora) as horario
    FROM registros_ponto
    WHERE usuario_id = ? AND data_referencia = ?
    ORDER BY data_hora
");
$stmt->bind_param('is', $userId, $hoje);
$stmt->execute();
$pontoHoje = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Organiza os registros por tipo
$pontoMap = [];
foreach ($pontoHoje as $p) {
    $pontoMap[$p['tipo']] = substr($p['horario'], 0, 5);
}

// Calcula horas trabalhadas hoje
$horasHoje = calcularHorasTrabalhadas(
    $pontoMap['entrada']        ?? null,
    $pontoMap['saida']          ?? null,
    $pontoMap['almoco_saida']   ?? null,
    $pontoMap['almoco_retorno'] ?? null
);

// ---- Próximo serviço pendente ----
$stmt = $conn->prepare("
    SELECT s.titulo, s.prioridade, ss.status
    FROM servicos_status ss
    INNER JOIN servicos s ON s.id = ss.servico_id
    WHERE ss.usuario_id = ? AND ss.status != 'concluido' AND s.status_geral = 'ativo'
    ORDER BY FIELD(s.prioridade,'urgente','alta','media','baixa')
    LIMIT 1
");
$stmt->bind_param('i', $userId);
$stmt->execute();
$proximoServico = $stmt->get_result()->fetch_assoc();
$stmt->close();

// ---- Resumo da folha do mês atual ----
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->bind_param('i', $userId);
$stmt->execute();
$dadosFuncionario = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Busca total de horas trabalhadas no mês
$stmt = $conn->prepare("
    SELECT
        data_referencia,
        MAX(CASE WHEN tipo='entrada'        THEN TIME(data_hora) END) as entrada,
        MAX(CASE WHEN tipo='saida'          THEN TIME(data_hora) END) as saida,
        MAX(CASE WHEN tipo='almoco_saida'   THEN TIME(data_hora) END) as almoco_saida,
        MAX(CASE WHEN tipo='almoco_retorno' THEN TIME(data_hora) END) as almoco_retorno
    FROM registros_ponto
    WHERE usuario_id = ? AND DATE_FORMAT(data_referencia, '%Y-%m') = ?
    GROUP BY data_referencia
");
$stmt->bind_param('is', $userId, $mes);
$stmt->execute();
$registrosMes = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$totalHorasDecimal = 0;
foreach ($registrosMes as $r) {
    $h = calcularHorasTrabalhadas($r['entrada'], $r['saida'], $r['almoco_saida'], $r['almoco_retorno']);
    $totalHorasDecimal += horasParaDecimal($h);
}

$folha = calcularFolhaPagamento($dadosFuncionario, $totalHorasDecimal);

$prioridadeBadge = [
    'urgente' => 'badge-urgente',
    'alta'    => 'badge-alta',
    'media'   => 'badge-media',
    'baixa'   => 'badge-baixa',
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema RH</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="wrapper">
    <?php renderSidebarFuncionario('dashboard'); ?>

    <div class="main-content">
        <?php renderTopbar('Meu Dashboard'); ?>

        <div class="content">
            <div id="alerts-container"><?php exibirAlertas(); ?></div>

            <!-- Boas-vindas -->
            <div style="margin-bottom:24px;">
                <h2 style="font-size:1.4rem; color:#1e3a5f;">
                    👋 Olá, <?= sanitizar($usuario['nome']) ?>!
                </h2>
                <p class="text-muted">
                    <?= sanitizar($dadosFuncionario['cargo'] ?? '') ?> — <?= sanitizar($dadosFuncionario['setor'] ?? '') ?> |
                    <?= date('l, d \d\e F \d\e Y') ?>
                </p>
            </div>

            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:20px;">

                <!-- Card: Ponto de Hoje -->
                <div class="panel">
                    <div class="panel-header">
                        <h3>⏱️ Ponto de Hoje</h3>
                        <a href="ponto.php" class="btn btn-sm btn-primary">Registrar</a>
                    </div>
                    <div class="panel-body">
                        <div class="ponto-status-grid" style="grid-template-columns: 1fr 1fr;">
                            <div class="ponto-status-item entrada">
                                <div class="label">🟢 Entrada</div>
                                <div class="value"><?= $pontoMap['entrada'] ?? '—' ?></div>
                            </div>
                            <div class="ponto-status-item almoco">
                                <div class="label">🟡 Saída Almoço</div>
                                <div class="value"><?= $pontoMap['almoco_saida'] ?? '—' ?></div>
                            </div>
                            <div class="ponto-status-item almoco">
                                <div class="label">🟡 Retorno Almoço</div>
                                <div class="value"><?= $pontoMap['almoco_retorno'] ?? '—' ?></div>
                            </div>
                            <div class="ponto-status-item saida">
                                <div class="label">🔴 Saída</div>
                                <div class="value"><?= $pontoMap['saida'] ?? '—' ?></div>
                            </div>
                        </div>
                        <div style="text-align:center; margin-top:12px;">
                            <span class="badge badge-primary" style="font-size:1rem; padding:6px 16px;">
                                ⏱️ Total: <?= $horasHoje ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Card: Próximo Serviço -->
                <div class="panel">
                    <div class="panel-header">
                        <h3>📋 Próximo Serviço</h3>
                        <a href="servicos.php" class="btn btn-sm btn-info">Ver Todos</a>
                    </div>
                    <div class="panel-body">
                        <?php if ($proximoServico): ?>
                            <div style="padding:12px; background:#f8f9fa; border-radius:8px;">
                                <div style="font-weight:600; margin-bottom:8px;">
                                    <?= sanitizar($proximoServico['titulo']) ?>
                                </div>
                                <div class="d-flex gap-2">
                                    <span class="badge <?= $prioridadeBadge[$proximoServico['prioridade']] ?>">
                                        <?= ucfirst($proximoServico['prioridade']) ?>
                                    </span>
                                    <span class="badge badge-warning">
                                        <?= $proximoServico['status'] === 'em_andamento' ? '🔄 Em Andamento' : '⏳ Pendente' ?>
                                    </span>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="empty-state" style="padding:20px;">
                                <div class="empty-icon">✅</div>
                                <p>Nenhum serviço pendente!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Card: Resumo da Folha -->
                <div class="panel">
                    <div class="panel-header">
                        <h3>💰 Folha — <?= nomeMes(date('n')) . ' ' . date('Y') ?></h3>
                        <a href="folha.php" class="btn btn-sm btn-success">Ver Detalhes</a>
                    </div>
                    <div class="panel-body">
                        <div class="folha-row">
                            <span class="folha-label">Salário Base</span>
                            <span class="folha-value positive">R$ <?= number_format($folha['salario_base'], 2, ',', '.') ?></span>
                        </div>
                        <div class="folha-row">
                            <span class="folha-label">INSS</span>
                            <span class="folha-value negative">- R$ <?= number_format($folha['inss'], 2, ',', '.') ?></span>
                        </div>
                        <div class="folha-row">
                            <span class="folha-label">IRRF</span>
                            <span class="folha-value negative">- R$ <?= number_format($folha['irrf'], 2, ',', '.') ?></span>
                        </div>
                        <div class="folha-row" style="border-top:2px solid #e9ecef; margin-top:8px; padding-top:8px;">
                            <span class="folha-label fw-bold">Salário Líquido</span>
                            <span class="folha-value positive fw-bold" style="font-size:1.1rem;">
                                R$ <?= number_format($folha['salario_liquido'], 2, ',', '.') ?>
                            </span>
                        </div>
                        <p class="text-muted mt-1" style="font-size:0.78rem;">
                            <?= count($registrosMes) ?> dias trabalhados | <?= number_format($totalHorasDecimal, 1) ?>h registradas
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<script src="../assets/js/main.js"></script>
</body>
</html>
