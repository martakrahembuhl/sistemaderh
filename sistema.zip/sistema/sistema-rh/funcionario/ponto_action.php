<?php
/**
 * Processamento AJAX do Registro de Ponto
 * Recebe POST com o tipo de ponto e registra no banco
 * Retorna JSON com sucesso ou erro
 */
session_start();
require_once '../config/db.php';
require_once '../includes/auth.php';

// Define o cabeçalho de resposta como JSON
header('Content-Type: application/json; charset=utf-8');

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'message' => 'Sessão expirada. Faça login novamente.']);
    exit;
}

// Aceita apenas requisições POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido.']);
    exit;
}

$userId = (int)$_SESSION['usuario_id'];
$tipo   = trim($_POST['tipo'] ?? '');
$hoje   = date('Y-m-d');
$agora  = date('Y-m-d H:i:s');

// Tipos válidos de registro
$tiposValidos = ['entrada', 'saida', 'almoco_saida', 'almoco_retorno'];

if (!in_array($tipo, $tiposValidos)) {
    echo json_encode(['success' => false, 'message' => 'Tipo de registro inválido.']);
    exit;
}

// ---- Verifica se já existe registro deste tipo hoje ----
$stmt = $conn->prepare("
    SELECT id FROM registros_ponto
    WHERE usuario_id = ? AND tipo = ? AND data_referencia = ?
    LIMIT 1
");
$stmt->bind_param('iss', $userId, $tipo, $hoje);
$stmt->execute();
$existente = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($existente) {
    $labels = [
        'entrada'        => 'Entrada',
        'saida'          => 'Saída',
        'almoco_saida'   => 'Saída para almoço',
        'almoco_retorno' => 'Retorno do almoço',
    ];
    echo json_encode([
        'success' => false,
        'message' => $labels[$tipo] . ' já foi registrada hoje.'
    ]);
    exit;
}

// ---- Validações de ordem dos registros ----
// Não pode registrar saída sem entrada
if ($tipo === 'saida') {
    $stmt = $conn->prepare("SELECT id FROM registros_ponto WHERE usuario_id=? AND tipo='entrada' AND data_referencia=?");
    $stmt->bind_param('is', $userId, $hoje);
    $stmt->execute();
    if (!$stmt->get_result()->fetch_assoc()) {
        echo json_encode(['success' => false, 'message' => 'Registre a entrada antes de registrar a saída.']);
        $stmt->close();
        exit;
    }
    $stmt->close();
}

// Não pode registrar saída almoço sem entrada
if ($tipo === 'almoco_saida') {
    $stmt = $conn->prepare("SELECT id FROM registros_ponto WHERE usuario_id=? AND tipo='entrada' AND data_referencia=?");
    $stmt->bind_param('is', $userId, $hoje);
    $stmt->execute();
    if (!$stmt->get_result()->fetch_assoc()) {
        echo json_encode(['success' => false, 'message' => 'Registre a entrada antes de sair para o almoço.']);
        $stmt->close();
        exit;
    }
    $stmt->close();
}

// Não pode registrar retorno almoço sem saída almoço
if ($tipo === 'almoco_retorno') {
    $stmt = $conn->prepare("SELECT id FROM registros_ponto WHERE usuario_id=? AND tipo='almoco_saida' AND data_referencia=?");
    $stmt->bind_param('is', $userId, $hoje);
    $stmt->execute();
    if (!$stmt->get_result()->fetch_assoc()) {
        echo json_encode(['success' => false, 'message' => 'Registre a saída para almoço antes do retorno.']);
        $stmt->close();
        exit;
    }
    $stmt->close();
}

// ---- Insere o registro de ponto ----
$stmt = $conn->prepare("
    INSERT INTO registros_ponto (usuario_id, tipo, data_hora, data_referencia)
    VALUES (?, ?, ?, ?)
");
$stmt->bind_param('isss', $userId, $tipo, $agora, $hoje);

if ($stmt->execute()) {
    $labels = [
        'entrada'        => '🟢 Entrada registrada com sucesso!',
        'saida'          => '🔴 Saída registrada com sucesso!',
        'almoco_saida'   => '🟡 Saída para almoço registrada!',
        'almoco_retorno' => '🟡 Retorno do almoço registrado!',
    ];
    echo json_encode([
        'success'  => true,
        'message'  => $labels[$tipo],
        'horario'  => date('H:i'),
        'tipo'     => $tipo,
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao registrar ponto. Tente novamente.'
    ]);
}

$stmt->close();
