<?php
/**
 * Folha de Pagamento do Funcionário
 * Exibe proventos, descontos, benefícios e salário líquido
 */
session_start();
define('BASE_URL', '..');
require_once '../config/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/layout.php';

verificarFuncionario();

$userId = $_SESSION['usuario_id'];

// ---- Seletor de mês/ano ----
$mes = (int)($_GET['mes'] ?? date('n'));
$ano = (int)($_GET['ano'] ?? date('Y'));

// Valida mês e ano
if ($mes < 1 || $mes > 12) $mes = date('n');
if ($ano < 2020 || $ano > date('Y')) $ano = date('Y');

$mesAno = sprintf('%04d-%02d', $ano, $mes);

// ---- Dados do funcionário ----
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->bind_param('i', $userId);
$stmt->execute();
$funcionario = $stmt->get_result()->fetch_assoc();
$stmt->close();

// ---- Registros de ponto do mês ----
$stmt = $conn->prepare("
    SELECT
        rp.data_referencia,
        MAX(CASE WHEN rp.tipo='entrada'        THEN TIME(rp.data_hora) END) as entrada,
        MAX(CASE WHEN rp.tipo='saida'          THEN TIME(rp.data_hora) END) as saida,
        MAX(CASE WHEN rp.tipo='almoco_saida'   THEN TIME(rp.data_hora) END) as almoco_saida,
        MAX(CASE WHEN rp.tipo='almoco_retorno' THEN TIME(rp.data_hora) END) as almoco_retorno,
        MAX(CASE WHEN rp.observacao LIKE '%admin%' THEN 1 ELSE 0 END) as corrigido
    FROM registros_ponto rp
    WHERE rp.usuario_id = ? AND DATE_FORMAT(rp.data_referencia, '%Y-%m') = ?
    GROUP BY rp.data_referencia
    ORDER BY rp.data_referencia
");
$stmt->bind_param('is', $userId, $mesAno);
$stmt->execute();
$registros = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// ---- Calcula total de horas trabalhadas ----
$totalHorasDecimal = 0;
$diasTrabalhados   = 0;
foreach ($registros as &$r) {
    $h = calcularHorasTrabalhadas($r['entrada'], $r['saida'], $r['almoco_saida'], $r['almoco_retorno']);
    $r['total_horas'] = $h;
    $dec = horasParaDecimal($h);
    $r['total_decimal'] = $dec;
    $totalHorasDecimal += $dec;
    if ($r['entrada']) $diasTrabalhados++;
}
unset($r);

// Dias úteis do mês (aproximado: conta dias úteis no mês)
$diasUteis = 0;
$primeiroDia = mktime(0, 0, 0, $mes, 1, $ano);
$ultimoDia   = mktime(0, 0, 0, $mes + 1, 0, $ano);
for ($d = $primeiroDia; $d <= $ultimoDia; $d += 86400) {
    $diaSemana = date('N', $d); // 1=seg, 7=dom
    if ($diaSemana <= 5) $diasUteis++;
}

// ---- Calcula a folha de pagamento ----
$folha = calcularFolhaPagamento($funcionario, $totalHorasDecimal, $diasUteis);

// Gera lista de anos para o seletor
$anoAtual = date('Y');
$anos = range($anoAtual, max(2020, $anoAtual - 3));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Folha de Pagamento - Sistema RH</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        @media print {
            .sidebar, .topbar, .sidebar-overlay, .no-print { display: none !important; }
            .main-content { margin-left: 0 !important; }
            .content { padding: 0 !important; }
        }
    </style>
</head>
<body>
<div class="wrapper">
    <?php renderSidebarFuncionario('folha'); ?>

    <div class="main-content">
        <?php renderTopbar('Folha de Pagamento'); ?>

        <div class="content">
            <div id="alerts-container"><?php exibirAlertas(); ?></div>

            <!-- Seletor de mês/ano -->
            <form method="GET" class="filters-bar no-print">
                <div class="form-group">
                    <label>Mês</label>
                    <select name="mes" class="form-control">
                        <?php for ($m = 1; $m <= 12; $m++): ?>
                            <option value="<?= $m ?>" <?= $m === $mes ? 'selected' : '' ?>>
                                <?= nomeMes($m) ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Ano</label>
                    <select name="ano" class="form-control">
                        <?php foreach ($anos as $a): ?>
                            <option value="<?= $a ?>" <?= $a === $ano ? 'selected' : '' ?>><?= $a ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" style="align-self:flex-end;">
                    <button type="submit" class="btn btn-primary">📅 Visualizar</button>
                    <button type="button" class="btn btn-secondary" onclick="window.print()">🖨️ Imprimir</button>
                </div>
            </form>

            <!-- Cabeçalho da folha -->
            <div class="panel">
                <div class="panel-header" style="background: linear-gradient(135deg, #1e3a5f, #2d5986); color:#fff; border-radius:8px 8px 0 0;">
                    <div>
                        <h3 style="color:#fff; font-size:1.1rem;">💰 Folha de Pagamento</h3>
                        <p style="color:rgba(255,255,255,0.8); font-size:0.85rem; margin-top:4px;">
                            Período: <?= nomeMes($mes) ?> / <?= $ano ?>
                        </p>
                    </div>
                    <div style="text-align:right; color:rgba(255,255,255,0.9); font-size:0.85rem;">
                        <div><strong><?= sanitizar($funcionario['nome']) ?></strong></div>
                        <div><?= sanitizar($funcionario['cargo'] ?? '—') ?> — <?= sanitizar($funcionario['setor'] ?? '—') ?></div>
                    </div>
                </div>
                <div class="panel-body">
                    <div style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:24px; flex-wrap:wrap;">

                        <!-- PROVENTOS -->
                        <div class="folha-section">
                            <h4 style="color: var(--success);">📈 Proventos</h4>
                            <div class="folha-row">
                                <span class="folha-label">Salário Base</span>
                                <span class="folha-value positive">R$ <?= number_format($folha['salario_base'], 2, ',', '.') ?></span>
                            </div>
                            <?php if ($folha['valor_horas_extras'] > 0): ?>
                                <div class="folha-row">
                                    <span class="folha-label">Horas Extras (<?= number_format($folha['horas_extras_decimal'], 1) ?>h × 150%)</span>
                                    <span class="folha-value positive">R$ <?= number_format($folha['valor_horas_extras'], 2, ',', '.') ?></span>
                                </div>
                            <?php endif; ?>
                            <div class="folha-row" style="border-top:2px solid #e9ecef; margin-top:8px; padding-top:8px;">
                                <span class="folha-label fw-bold">Total Bruto</span>
                                <span class="folha-value positive fw-bold">R$ <?= number_format($folha['salario_bruto'], 2, ',', '.') ?></span>
                            </div>
                        </div>

                        <!-- DESCONTOS -->
                        <div class="folha-section">
                            <h4 style="color: var(--danger);">📉 Descontos</h4>
                            <div class="folha-row">
                                <span class="folha-label">INSS (Progressivo)</span>
                                <span class="folha-value negative">- R$ <?= number_format($folha['inss'], 2, ',', '.') ?></span>
                            </div>
                            <div class="folha-row">
                                <span class="folha-label">IRRF</span>
                                <span class="folha-value negative">- R$ <?= number_format($folha['irrf'], 2, ',', '.') ?></span>
                            </div>
                            <div class="folha-row" style="border-top:2px solid #e9ecef; margin-top:8px; padding-top:8px;">
                                <span class="folha-label fw-bold">Total Descontos</span>
                                <span class="folha-value negative fw-bold">- R$ <?= number_format($folha['total_descontos'], 2, ',', '.') ?></span>
                            </div>
                        </div>

                        <!-- BENEFÍCIOS -->
                        <div class="folha-section">
                            <h4 style="color: var(--info);">🎁 Benefícios</h4>
                            <div class="folha-row">
                                <span class="folha-label">Vale Transporte</span>
                                <span class="folha-value positive">R$ <?= number_format($folha['vale_transporte'], 2, ',', '.') ?></span>
                            </div>
                            <div class="folha-row">
                                <span class="folha-label">Vale Refeição</span>
                                <span class="folha-value positive">R$ <?= number_format($folha['vale_refeicao'], 2, ',', '.') ?></span>
                            </div>
                            <div class="folha-row" style="border-top:2px solid #e9ecef; margin-top:8px; padding-top:8px;">
                                <span class="folha-label fw-bold">Total Benefícios</span>
                                <span class="folha-value positive fw-bold">R$ <?= number_format($folha['total_beneficios'], 2, ',', '.') ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Salário Líquido em destaque -->
                    <div class="folha-total">
                        <div>
                            <div class="total-label">💵 SALÁRIO LÍQUIDO</div>
                            <div style="font-size:0.85rem; opacity:0.85; margin-top:4px;">
                                <?= $diasTrabalhados ?> dias trabalhados | <?= number_format($totalHorasDecimal, 1) ?>h registradas
                            </div>
                        </div>
                        <div class="total-value">R$ <?= number_format($folha['salario_liquido'], 2, ',', '.') ?></div>
                    </div>

                    <!-- Nota sobre cálculos -->
                    <p class="text-muted mt-2" style="font-size:0.78rem;">
                        * Cálculos baseados na tabela INSS e IRRF 2024. Valores aproximados para fins informativos.
                        Dias úteis do mês: <?= $diasUteis ?>.
                    </p>
                </div>
            </div>

            <!-- Tabela de registros do mês -->
            <div class="panel">
                <div class="panel-header">
                    <h3>📅 Registros de Ponto — <?= nomeMes($mes) ?>/<?= $ano ?></h3>
                    <span class="badge badge-primary"><?= $diasTrabalhados ?> dias</span>
                </div>
                <?php if (empty($registros)): ?>
                    <div class="empty-state">
                        <div class="empty-icon">📭</div>
                        <p>Nenhum registro de ponto neste período.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Entrada</th>
                                    <th>Saída Almoço</th>
                                    <th>Retorno Almoço</th>
                                    <th>Saída</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($registros as $r): ?>
                                    <tr>
                                        <td>
                                            <?= date('d/m/Y', strtotime($r['data_referencia'])) ?>
                                            (<?= ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'][date('w', strtotime($r['data_referencia']))] ?>)
                                            <?php if ($r['corrigido']): ?>
                                                <span class="icon-corrected" title="Corrigido pelo admin">✏️</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-success"><?= $r['entrada']        ? substr($r['entrada'], 0, 5)        : '—' ?></td>
                                        <td class="text-warning"><?= $r['almoco_saida']   ? substr($r['almoco_saida'], 0, 5)   : '—' ?></td>
                                        <td class="text-warning"><?= $r['almoco_retorno'] ? substr($r['almoco_retorno'], 0, 5) : '—' ?></td>
                                        <td class="text-danger"><?= $r['saida']           ? substr($r['saida'], 0, 5)          : '—' ?></td>
                                        <td>
                                            <span class="badge badge-primary"><?= $r['total_horas'] ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr style="background:#f8f9fa; font-weight:700;">
                                    <td colspan="5" style="text-align:right; padding:12px 14px;">Total do Mês:</td>
                                    <td style="padding:12px 14px;">
                                        <span class="badge badge-success" style="font-size:0.9rem;">
                                            <?= number_format($totalHorasDecimal, 1) ?>h
                                        </span>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>
<script src="../assets/js/main.js"></script>
</body>
</html>
