<?php
/**
 * Registro de Ponto do Funcionário
 * Relógio em tempo real + botões de ponto + histórico navegável
 */
session_start();
define('BASE_URL', '..');
require_once '../config/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/layout.php';

verificarFuncionario();

$userId = $_SESSION['usuario_id'];

// ---- Navegação de período (semana/mês) ----
// Usa offset de semanas para navegar no histórico
$semanaOffset = (int)($_GET['semana'] ?? 0); // 0 = semana atual, -1 = semana anterior, etc.

// Calcula início e fim da semana com base no offset
$inicioSemana = new DateTime();
$inicioSemana->modify('monday this week');
$inicioSemana->modify("$semanaOffset weeks");
$fimSemana = clone $inicioSemana;
$fimSemana->modify('+6 days');

$dataInicio = $inicioSemana->format('Y-m-d');
$dataFim    = $fimSemana->format('Y-m-d');
$labelPeriodo = $inicioSemana->format('d/m') . ' a ' . $fimSemana->format('d/m/Y');

// ---- Registros de ponto de hoje ----
$hoje = date('Y-m-d');
$stmt = $conn->prepare("
    SELECT tipo, TIME(data_hora) as horario, observacao
    FROM registros_ponto
    WHERE usuario_id = ? AND data_referencia = ?
    ORDER BY data_hora
");
$stmt->bind_param('is', $userId, $hoje);
$stmt->execute();
$pontoHoje = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Organiza por tipo
$pontoMap = [];
foreach ($pontoHoje as $p) {
    $pontoMap[$p['tipo']] = [
        'horario'    => substr($p['horario'], 0, 5),
        'corrigido'  => strpos($p['observacao'] ?? '', 'admin') !== false,
    ];
}

// Determina quais botões estão disponíveis
$temEntrada        = isset($pontoMap['entrada']);
$temAlmocoSaida    = isset($pontoMap['almoco_saida']);
$temAlmocoRetorno  = isset($pontoMap['almoco_retorno']);
$temSaida          = isset($pontoMap['saida']);

// Horas trabalhadas hoje
$horasHoje = calcularHorasTrabalhadas(
    $pontoMap['entrada']['horario']        ?? null,
    $pontoMap['saida']['horario']          ?? null,
    $pontoMap['almoco_saida']['horario']   ?? null,
    $pontoMap['almoco_retorno']['horario'] ?? null
);

// ---- Histórico da semana selecionada ----
$stmt = $conn->prepare("
    SELECT
        rp.data_referencia,
        MAX(CASE WHEN rp.tipo='entrada'        THEN TIME(rp.data_hora) END) as entrada,
        MAX(CASE WHEN rp.tipo='saida'          THEN TIME(rp.data_hora) END) as saida,
        MAX(CASE WHEN rp.tipo='almoco_saida'   THEN TIME(rp.data_hora) END) as almoco_saida,
        MAX(CASE WHEN rp.tipo='almoco_retorno' THEN TIME(rp.data_hora) END) as almoco_retorno,
        MAX(CASE WHEN rp.observacao LIKE '%admin%' THEN 1 ELSE 0 END) as corrigido
    FROM registros_ponto rp
    WHERE rp.usuario_id = ? AND rp.data_referencia BETWEEN ? AND ?
    GROUP BY rp.data_referencia
    ORDER BY rp.data_referencia
");
$stmt->bind_param('iss', $userId, $dataInicio, $dataFim);
$stmt->execute();
$historico = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Cria um mapa de datas para preencher todos os dias da semana
$historicoMap = [];
foreach ($historico as $h) {
    $historicoMap[$h['data_referencia']] = $h;
}

// Gera todos os dias da semana (seg a sex)
$diasSemana = [];
$cursor = clone $inicioSemana;
for ($i = 0; $i < 7; $i++) {
    $data = $cursor->format('Y-m-d');
    $diasSemana[] = [
        'data'    => $data,
        'label'   => $cursor->format('d/m'),
        'diaSem'  => ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'][$cursor->format('w')],
        'registro'=> $historicoMap[$data] ?? null,
        'ehHoje'  => $data === $hoje,
    ];
    $cursor->modify('+1 day');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Ponto - Sistema RH</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="wrapper">
    <?php renderSidebarFuncionario('ponto'); ?>

    <div class="main-content">
        <?php renderTopbar('Registro de Ponto'); ?>

        <div class="content">
            <div id="alerts-container"><?php exibirAlertas(); ?></div>

            <!-- Relógio Digital -->
            <div class="clock-container">
                <div class="clock-time" id="clock-time">00:00:00</div>
                <div class="clock-date" id="clock-date"></div>
            </div>

            <!-- Botões de Ponto -->
            <div class="ponto-buttons">
                <!-- Entrada -->
                <button
                    class="btn-ponto entrada"
                    onclick="registrarPonto('entrada')"
                    <?= $temEntrada ? 'disabled title="Entrada já registrada"' : '' ?>>
                    <span class="ponto-icon">🟢</span>
                    ENTRADA
                    <?php if ($temEntrada): ?>
                        <small><?= $pontoMap['entrada']['horario'] ?></small>
                    <?php endif; ?>
                </button>

                <!-- Almoço (alterna entre saída e retorno) -->
                <?php if (!$temAlmocoSaida): ?>
                    <button
                        class="btn-ponto almoco"
                        onclick="registrarPonto('almoco_saida')"
                        <?= !$temEntrada ? 'disabled title="Registre a entrada primeiro"' : '' ?>>
                        <span class="ponto-icon">🟡</span>
                        SAÍDA ALMOÇO
                    </button>
                <?php elseif (!$temAlmocoRetorno): ?>
                    <button
                        class="btn-ponto almoco"
                        onclick="registrarPonto('almoco_retorno')">
                        <span class="ponto-icon">🟡</span>
                        RETORNO ALMOÇO
                        <small><?= $pontoMap['almoco_saida']['horario'] ?></small>
                    </button>
                <?php else: ?>
                    <button class="btn-ponto almoco" disabled>
                        <span class="ponto-icon">🟡</span>
                        ALMOÇO ✓
                        <small><?= $pontoMap['almoco_saida']['horario'] ?> - <?= $pontoMap['almoco_retorno']['horario'] ?></small>
                    </button>
                <?php endif; ?>

                <!-- Saída -->
                <button
                    class="btn-ponto saida"
                    onclick="registrarPonto('saida')"
                    <?= ($temSaida || !$temEntrada) ? 'disabled title="' . ($temSaida ? 'Saída já registrada' : 'Registre a entrada primeiro') . '"' : '' ?>>
                    <span class="ponto-icon">🔴</span>
                    SAÍDA
                    <?php if ($temSaida): ?>
                        <small><?= $pontoMap['saida']['horario'] ?></small>
                    <?php endif; ?>
                </button>
            </div>

            <!-- Status do ponto hoje -->
            <div class="panel">
                <div class="panel-header">
                    <h3>📊 Status de Hoje — <?= date('d/m/Y') ?></h3>
                </div>
                <div class="panel-body">
                    <div class="ponto-status-grid">
                        <div class="ponto-status-item entrada">
                            <div class="label">🟢 Entrada</div>
                            <div class="value">
                                <?= isset($pontoMap['entrada']) ? $pontoMap['entrada']['horario'] : '—' ?>
                                <?php if (isset($pontoMap['entrada']['corrigido']) && $pontoMap['entrada']['corrigido']): ?>
                                    <span class="icon-corrected" title="Corrigido pelo admin">✏️</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="ponto-status-item almoco">
                            <div class="label">🟡 Saída Almoço</div>
                            <div class="value"><?= isset($pontoMap['almoco_saida']) ? $pontoMap['almoco_saida']['horario'] : '—' ?></div>
                        </div>
                        <div class="ponto-status-item almoco">
                            <div class="label">🟡 Retorno Almoço</div>
                            <div class="value"><?= isset($pontoMap['almoco_retorno']) ? $pontoMap['almoco_retorno']['horario'] : '—' ?></div>
                        </div>
                        <div class="ponto-status-item saida">
                            <div class="label">🔴 Saída</div>
                            <div class="value">
                                <?= isset($pontoMap['saida']) ? $pontoMap['saida']['horario'] : '—' ?>
                                <?php if (isset($pontoMap['saida']['corrigido']) && $pontoMap['saida']['corrigido']): ?>
                                    <span class="icon-corrected" title="Corrigido pelo admin">✏️</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="ponto-status-item total">
                            <div class="label">⏱️ Total Hoje</div>
                            <div class="value"><?= $horasHoje ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Histórico navegável -->
            <div class="panel">
                <div class="panel-header">
                    <h3>📅 Histórico Semanal</h3>
                </div>
                <div class="panel-body">
                    <!-- Navegação de semanas -->
                    <div class="history-nav">
                        <a href="?semana=<?= $semanaOffset - 1 ?>" class="btn-nav">◀ Anterior</a>
                        <span class="period-label">📅 <?= $labelPeriodo ?></span>
                        <?php if ($semanaOffset < 0): ?>
                            <a href="?semana=<?= $semanaOffset + 1 ?>" class="btn-nav">Próxima ▶</a>
                        <?php else: ?>
                            <span class="btn-nav" style="opacity:0.4; cursor:default;">Próxima ▶</span>
                        <?php endif; ?>
                    </div>

                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Dia</th>
                                    <th>Data</th>
                                    <th>Entrada</th>
                                    <th>Saída Almoço</th>
                                    <th>Retorno Almoço</th>
                                    <th>Saída</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($diasSemana as $dia): ?>
                                    <?php
                                    $reg = $dia['registro'];
                                    $horas = $reg ? calcularHorasTrabalhadas(
                                        $reg['entrada'], $reg['saida'],
                                        $reg['almoco_saida'], $reg['almoco_retorno']
                                    ) : '—';
                                    $rowStyle = $dia['ehHoje'] ? 'background:#e8f0fe;' : '';
                                    ?>
                                    <tr style="<?= $rowStyle ?>">
                                        <td>
                                            <strong><?= $dia['diaSem'] ?></strong>
                                            <?php if ($dia['ehHoje']): ?>
                                                <span class="badge badge-primary" style="font-size:0.65rem;">Hoje</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= $dia['label'] ?></td>
                                        <td class="text-success">
                                            <?= $reg && $reg['entrada'] ? substr($reg['entrada'], 0, 5) : '—' ?>
                                            <?php if ($reg && $reg['corrigido']): ?>
                                                <span class="icon-corrected" title="Corrigido pelo admin">✏️</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-warning"><?= $reg && $reg['almoco_saida']   ? substr($reg['almoco_saida'], 0, 5)   : '—' ?></td>
                                        <td class="text-warning"><?= $reg && $reg['almoco_retorno'] ? substr($reg['almoco_retorno'], 0, 5) : '—' ?></td>
                                        <td class="text-danger"><?= $reg && $reg['saida']           ? substr($reg['saida'], 0, 5)          : '—' ?></td>
                                        <td>
                                            <?php if ($reg && $reg['entrada']): ?>
                                                <span class="badge badge-primary"><?= $horas ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">—</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<script src="../assets/js/main.js"></script>
</body>
</html>
