<?php
/**
 * Serviços do Funcionário
 * Exibe apenas serviços do setor e cargo do funcionário logado
 * Permite atualizar o status de cada serviço
 */
session_start();
define('BASE_URL', '..');
require_once '../config/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/layout.php';

verificarFuncionario();

$userId = $_SESSION['usuario_id'];
$setor  = $_SESSION['setor']  ?? '';
$cargo  = $_SESSION['cargo']  ?? '';

// ---- Processar atualização de status ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    $acao      = $_POST['acao'];
    $servicoId = (int)($_POST['servico_id'] ?? 0);

    $statusMap = [
        'iniciar'  => 'em_andamento',
        'concluir' => 'concluido',
    ];

    if (isset($statusMap[$acao]) && $servicoId > 0) {
        $novoStatus = $statusMap[$acao];

        // Verifica se o serviço pertence ao setor/cargo do funcionário
        $stmt = $conn->prepare("
            SELECT ss.id FROM servicos_status ss
            INNER JOIN servicos s ON s.id = ss.servico_id
            WHERE ss.servico_id = ? AND ss.usuario_id = ?
              AND s.status_geral = 'ativo'
        ");
        $stmt->bind_param('ii', $servicoId, $userId);
        $stmt->execute();
        $registro = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($registro) {
            // Atualiza o status
            $stmt = $conn->prepare("
                UPDATE servicos_status SET status = ? WHERE servico_id = ? AND usuario_id = ?
            ");
            $stmt->bind_param('sii', $novoStatus, $servicoId, $userId);
            if ($stmt->execute()) {
                $labels = ['em_andamento' => 'Serviço iniciado!', 'concluido' => 'Serviço concluído!'];
                $_SESSION['msg_sucesso'] = $labels[$novoStatus];
            } else {
                $_SESSION['msg_erro'] = 'Erro ao atualizar status.';
            }
            $stmt->close();
        } else {
            $_SESSION['msg_erro'] = 'Serviço não encontrado ou sem permissão.';
        }
    }

    header('Location: servicos.php' . (isset($_GET['status']) ? '?status=' . urlencode($_GET['status']) : ''));
    exit;
}

// ---- Filtro por status ----
$filtroStatus = $_GET['status'] ?? '';

// ---- Busca serviços do setor/cargo do funcionário ----
$sql = "
    SELECT s.id, s.titulo, s.descricao, s.prioridade, s.setor, s.cargo, s.created_at,
           ss.status, ss.updated_at
    FROM servicos s
    INNER JOIN servicos_status ss ON ss.servico_id = s.id AND ss.usuario_id = ?
    WHERE s.status_geral = 'ativo'
";
$params = [$userId];
$types  = 'i';

if ($filtroStatus) {
    $sql .= " AND ss.status = ?";
    $params[] = $filtroStatus;
    $types   .= 's';
}

$sql .= " ORDER BY FIELD(s.prioridade,'urgente','alta','media','baixa'), s.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$servicos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Contagem por status para os filtros
$stmt = $conn->prepare("
    SELECT ss.status, COUNT(*) as total
    FROM servicos_status ss
    INNER JOIN servicos s ON s.id = ss.servico_id
    WHERE ss.usuario_id = ? AND s.status_geral = 'ativo'
    GROUP BY ss.status
");
$stmt->bind_param('i', $userId);
$stmt->execute();
$contagens = [];
foreach ($stmt->get_result()->fetch_all(MYSQLI_ASSOC) as $c) {
    $contagens[$c['status']] = $c['total'];
}
$stmt->close();

$prioridadeBadge = [
    'urgente' => 'badge-urgente',
    'alta'    => 'badge-alta',
    'media'   => 'badge-media',
    'baixa'   => 'badge-baixa',
];
$statusBadge = [
    'pendente'    => 'badge-warning',
    'em_andamento'=> 'badge-info',
    'concluido'   => 'badge-success',
];
$statusLabel = [
    'pendente'    => '⏳ Pendente',
    'em_andamento'=> '🔄 Em Andamento',
    'concluido'   => '✅ Concluído',
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Serviços - Sistema RH</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="wrapper">
    <?php renderSidebarFuncionario('servicos'); ?>

    <div class="main-content">
        <?php renderTopbar('Meus Serviços'); ?>

        <div class="content">
            <div id="alerts-container"><?php exibirAlertas(); ?></div>

            <!-- Filtros por status -->
            <div class="d-flex gap-2 mb-3" style="flex-wrap:wrap;">
                <a href="servicos.php"
                   class="btn btn-sm <?= !$filtroStatus ? 'btn-primary' : 'btn-outline btn-primary' ?>">
                    Todos (<?= array_sum($contagens) ?>)
                </a>
                <a href="?status=pendente"
                   class="btn btn-sm <?= $filtroStatus === 'pendente' ? 'btn-warning' : 'btn-outline btn-warning' ?>">
                    ⏳ Pendentes (<?= $contagens['pendente'] ?? 0 ?>)
                </a>
                <a href="?status=em_andamento"
                   class="btn btn-sm <?= $filtroStatus === 'em_andamento' ? 'btn-info' : 'btn-outline btn-info' ?>">
                    🔄 Em Andamento (<?= $contagens['em_andamento'] ?? 0 ?>)
                </a>
                <a href="?status=concluido"
                   class="btn btn-sm <?= $filtroStatus === 'concluido' ? 'btn-success' : 'btn-outline btn-success' ?>">
                    ✅ Concluídos (<?= $contagens['concluido'] ?? 0 ?>)
                </a>
            </div>

            <!-- Info do funcionário -->
            <div class="alert alert-info" style="margin-bottom:16px;">
                <span>ℹ️</span>
                <span>
                    Exibindo serviços para: <strong><?= sanitizar($setor) ?></strong>
                    <?= $cargo ? '/ <strong>' . sanitizar($cargo) . '</strong>' : '' ?>
                </span>
            </div>

            <!-- Lista de serviços -->
            <?php if (empty($servicos)): ?>
                <div class="panel">
                    <div class="empty-state">
                        <div class="empty-icon">📋</div>
                        <p>
                            <?php if ($filtroStatus): ?>
                                Nenhum serviço com status "<?= $statusLabel[$filtroStatus] ?? $filtroStatus ?>".
                            <?php else: ?>
                                Nenhum serviço atribuído ao seu setor/cargo no momento.
                            <?php endif; ?>
                        </p>
                        <?php if ($filtroStatus): ?>
                            <a href="servicos.php" class="btn btn-sm btn-primary mt-2">Ver Todos</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap:20px;">
                    <?php foreach ($servicos as $s): ?>
                        <div class="panel" style="border-top: 4px solid <?= $s['prioridade'] === 'urgente' ? '#dc3545' : ($s['prioridade'] === 'alta' ? '#fd7e14' : ($s['prioridade'] === 'media' ? '#ffc107' : '#28a745')) ?>;">
                            <div class="panel-header">
                                <div style="flex:1;">
                                    <h3 style="font-size:0.95rem;"><?= sanitizar($s['titulo']) ?></h3>
                                    <div style="margin-top:6px; display:flex; gap:6px; flex-wrap:wrap;">
                                        <span class="badge <?= $prioridadeBadge[$s['prioridade']] ?>">
                                            <?= ucfirst($s['prioridade']) ?>
                                        </span>
                                        <span class="badge <?= $statusBadge[$s['status']] ?>">
                                            <?= $statusLabel[$s['status']] ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-body">
                                <?php if ($s['descricao']): ?>
                                    <p style="color:#555; font-size:0.875rem; margin-bottom:14px; line-height:1.5;">
                                        <?= sanitizar($s['descricao']) ?>
                                    </p>
                                <?php endif; ?>

                                <p class="text-muted" style="font-size:0.75rem; margin-bottom:14px;">
                                    📁 <?= sanitizar($s['setor']) ?>
                                    <?= $s['cargo'] ? '/ 💼 ' . sanitizar($s['cargo']) : '' ?>
                                    <br>
                                    Criado em <?= date('d/m/Y', strtotime($s['created_at'])) ?>
                                    | Atualizado <?= date('d/m/Y H:i', strtotime($s['updated_at'])) ?>
                                </p>

                                <!-- Botões de ação -->
                                <div class="d-flex gap-2">
                                    <?php if ($s['status'] === 'pendente'): ?>
                                        <form method="POST" style="flex:1;">
                                            <input type="hidden" name="acao"       value="iniciar">
                                            <input type="hidden" name="servico_id" value="<?= $s['id'] ?>">
                                            <button type="submit" class="btn btn-info w-100"
                                                onclick="return confirm('Iniciar este serviço?')">
                                                🔄 Iniciar
                                            </button>
                                        </form>
                                    <?php elseif ($s['status'] === 'em_andamento'): ?>
                                        <form method="POST" style="flex:1;">
                                            <input type="hidden" name="acao"       value="concluir">
                                            <input type="hidden" name="servico_id" value="<?= $s['id'] ?>">
                                            <button type="submit" class="btn btn-success w-100"
                                                onclick="return confirm('Marcar como concluído?')">
                                                ✅ Concluir
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <button class="btn btn-secondary w-100 disabled" disabled>
                                            ✅ Concluído
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<script src="../assets/js/main.js"></script>
</body>
</html>
