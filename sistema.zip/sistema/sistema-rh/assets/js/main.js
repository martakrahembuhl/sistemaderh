/**
 * Sistema RH - JavaScript Principal
 * Funções: relógio, validações, AJAX, formatações, alertas
 */

// ============================================================
// Relógio em Tempo Real
// ============================================================
function iniciarRelogio() {
    const elTime = document.getElementById('clock-time');
    const elDate = document.getElementById('clock-date');
    if (!elTime) return;

    const diasSemana = ['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'];
    const meses = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];

    function atualizar() {
        const agora = new Date();
        const h = String(agora.getHours()).padStart(2, '0');
        const m = String(agora.getMinutes()).padStart(2, '0');
        const s = String(agora.getSeconds()).padStart(2, '0');
        elTime.textContent = `${h}:${m}:${s}`;

        if (elDate) {
            const dia = diasSemana[agora.getDay()];
            const d   = agora.getDate();
            const mes = meses[agora.getMonth()];
            const ano = agora.getFullYear();
            elDate.textContent = `${dia}, ${d} de ${mes} de ${ano}`;
        }
    }

    atualizar();
    setInterval(atualizar, 1000);
}

// ============================================================
// Relógio simples para topbar
// ============================================================
function iniciarRelogioTopbar() {
    const el = document.getElementById('topbar-time');
    if (!el) return;
    function atualizar() {
        const agora = new Date();
        const h = String(agora.getHours()).padStart(2, '0');
        const m = String(agora.getMinutes()).padStart(2, '0');
        el.textContent = `${h}:${m}`;
    }
    atualizar();
    setInterval(atualizar, 30000);
}

// ============================================================
// Formatação automática de CPF: 000.000.000-00
// ============================================================
function formatarCPF(input) {
    let v = input.value.replace(/\D/g, '').substring(0, 11);
    if (v.length > 9)      v = v.replace(/^(\d{3})(\d{3})(\d{3})(\d{0,2})/, '$1.$2.$3-$4');
    else if (v.length > 6) v = v.replace(/^(\d{3})(\d{3})(\d{0,3})/, '$1.$2.$3');
    else if (v.length > 3) v = v.replace(/^(\d{3})(\d{0,3})/, '$1.$2');
    input.value = v;
}

// ============================================================
// Formatação automática de Telefone: (00) 00000-0000
// ============================================================
function formatarTelefone(input) {
    let v = input.value.replace(/\D/g, '').substring(0, 11);
    if (v.length > 10)     v = v.replace(/^(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3');
    else if (v.length > 6) v = v.replace(/^(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
    else if (v.length > 2) v = v.replace(/^(\d{2})(\d{0,5})/, '($1) $2');
    else if (v.length > 0) v = v.replace(/^(\d{0,2})/, '($1');
    input.value = v;
}

// ============================================================
// Alertas com auto-dismiss
// ============================================================
function criarAlerta(mensagem, tipo = 'success', duracao = 4000) {
    const container = document.getElementById('alerts-container') || document.body;
    const alert = document.createElement('div');
    alert.className = `alert alert-${tipo}`;
    const icones = { success: '✅', danger: '❌', warning: '⚠️', info: 'ℹ️' };
    alert.innerHTML = `
        <span>${icones[tipo] || 'ℹ️'}</span>
        <span>${mensagem}</span>
        <button class="close-btn" onclick="this.parentElement.remove()">×</button>
    `;
    container.prepend(alert);
    if (duracao > 0) {
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 0.4s';
            setTimeout(() => alert.remove(), 400);
        }, duracao);
    }
}

// Fecha alertas existentes ao clicar no X
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('close-btn')) {
        e.target.closest('.alert')?.remove();
    }
});

// ============================================================
// Modal
// ============================================================
function abrirModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.classList.add('active');
}

function fecharModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.classList.remove('active');
}

// Fecha modal ao clicar fora
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
    }
});

// Fecha modal com ESC
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
    }
});

// ============================================================
// Toggle Sidebar Mobile
// ============================================================
function toggleSidebar() {
    const sidebar  = document.querySelector('.sidebar');
    const overlay  = document.querySelector('.sidebar-overlay');
    sidebar?.classList.toggle('open');
    overlay?.classList.toggle('active');
}

document.addEventListener('click', function(e) {
    if (e.target.classList.contains('sidebar-overlay')) {
        document.querySelector('.sidebar')?.classList.remove('open');
        e.target.classList.remove('active');
    }
});

// ============================================================
// Confirmação de exclusão
// ============================================================
function confirmarExclusao(mensagem) {
    return confirm(mensagem || 'Tem certeza que deseja excluir este registro? Esta ação não pode ser desfeita.');
}

// ============================================================
// Registro de Ponto via AJAX
// ============================================================
async function registrarPonto(tipo) {
    const btn = document.querySelector(`.btn-ponto.${tipo}`);
    if (btn) {
        btn.disabled = true;
        btn.style.opacity = '0.7';
    }

    try {
        const response = await fetch('../funcionario/ponto_action.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `tipo=${encodeURIComponent(tipo)}`
        });

        const data = await response.json();

        if (data.success) {
            criarAlerta(data.message, 'success');
            // Atualiza o status do ponto na tela após 800ms
            setTimeout(() => location.reload(), 800);
        } else {
            criarAlerta(data.message || 'Erro ao registrar ponto.', 'danger');
            if (btn) { btn.disabled = false; btn.style.opacity = ''; }
        }
    } catch (err) {
        criarAlerta('Erro de conexão. Tente novamente.', 'danger');
        if (btn) { btn.disabled = false; btn.style.opacity = ''; }
    }
}

// ============================================================
// Validação de formulários client-side
// ============================================================
function validarFormulario(formId) {
    const form = document.getElementById(formId);
    if (!form) return true;

    let valido = true;
    const campos = form.querySelectorAll('[required]');

    campos.forEach(campo => {
        campo.classList.remove('is-invalid');
        if (!campo.value.trim()) {
            campo.classList.add('is-invalid');
            valido = false;
        }
    });

    // Valida CPF se existir
    const cpfInput = form.querySelector('[name="cpf"]');
    if (cpfInput && cpfInput.value) {
        const cpfLimpo = cpfInput.value.replace(/\D/g, '');
        if (cpfLimpo.length !== 11) {
            cpfInput.classList.add('is-invalid');
            valido = false;
        }
    }

    // Valida senhas iguais se existir confirmação
    const senha1 = form.querySelector('[name="senha"]');
    const senha2 = form.querySelector('[name="senha_confirm"]');
    if (senha1 && senha2 && senha2.value && senha1.value !== senha2.value) {
        senha2.classList.add('is-invalid');
        criarAlerta('As senhas não coincidem.', 'warning');
        valido = false;
    }

    if (!valido) {
        criarAlerta('Preencha todos os campos obrigatórios.', 'warning');
    }

    return valido;
}

// ============================================================
// Inicialização ao carregar a página
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    iniciarRelogio();
    iniciarRelogioTopbar();

    // Aplica máscara de CPF
    document.querySelectorAll('[data-mask="cpf"]').forEach(el => {
        el.addEventListener('input', () => formatarCPF(el));
    });

    // Aplica máscara de telefone
    document.querySelectorAll('[data-mask="telefone"]').forEach(el => {
        el.addEventListener('input', () => formatarTelefone(el));
    });

    // Auto-dismiss em alertas existentes (vindos do PHP)
    document.querySelectorAll('.alert[data-auto-dismiss]').forEach(alert => {
        const delay = parseInt(alert.dataset.autoDismiss) || 4000;
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 0.4s';
            setTimeout(() => alert.remove(), 400);
        }, delay);
    });
});
