-- ============================================================
-- Sistema RH - Banco de Dados
-- Criado para fins didáticos
-- ============================================================

CREATE DATABASE IF NOT EXISTS sistema_rh
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE sistema_rh;

-- ============================================================
-- Tabela de Usuários (admins e funcionários)
-- ============================================================
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20),
    cpf VARCHAR(14) UNIQUE,
    endereco VARCHAR(255),
    setor VARCHAR(100),
    cargo VARCHAR(100),
    email VARCHAR(100),
    usuario VARCHAR(50) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('admin', 'funcionario') NOT NULL DEFAULT 'funcionario',
    salario_base DECIMAL(10,2) DEFAULT 0.00,
    vale_transporte DECIMAL(10,2) DEFAULT 0.00,
    vale_refeicao DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Tabela de Registros de Ponto
-- ============================================================
CREATE TABLE IF NOT EXISTS registros_ponto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    tipo ENUM('entrada', 'saida', 'almoco_saida', 'almoco_retorno') NOT NULL,
    data_hora DATETIME NOT NULL,
    data_referencia DATE NOT NULL,
    observacao TEXT,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Tabela de Correções de Ponto (feitas pelo admin)
-- ============================================================
CREATE TABLE IF NOT EXISTS correcoes_ponto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    admin_id INT NOT NULL,
    data_referencia DATE NOT NULL,
    entrada_corrigida TIME,
    saida_corrigida TIME,
    almoco_saida_corrigida TIME,
    almoco_retorno_corrigida TIME,
    motivo TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (admin_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Tabela de Serviços/Tarefas
-- ============================================================
CREATE TABLE IF NOT EXISTS servicos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT,
    setor VARCHAR(100),
    cargo VARCHAR(100),
    prioridade ENUM('baixa', 'media', 'alta', 'urgente') NOT NULL DEFAULT 'media',
    status_geral ENUM('ativo', 'encerrado') NOT NULL DEFAULT 'ativo',
    criado_por INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Tabela de Status dos Serviços por Funcionário
-- ============================================================
CREATE TABLE IF NOT EXISTS servicos_status (
    id INT AUTO_INCREMENT PRIMARY KEY,
    servico_id INT NOT NULL,
    usuario_id INT NOT NULL,
    status ENUM('pendente', 'em_andamento', 'concluido') NOT NULL DEFAULT 'pendente',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_servico_usuario (servico_id, usuario_id),
    FOREIGN KEY (servico_id) REFERENCES servicos(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Dados iniciais: Admin padrão
-- Login: admin / Senha: admin123
-- ============================================================
INSERT INTO usuarios (nome, usuario, senha, tipo, email, setor, cargo)
VALUES (
    'Administrador',
    'admin',
    '$2y$10$R.xdg6baWXDdZQue3hWQuOfeRKri5cQOnn2gXHxOctNT45kcNSwlq',
    'admin',
    'admin@empresa.com',
    'Administração',
    'Administrador'
);

-- ============================================================
-- Dados iniciais: Funcionário de teste
-- Login: joao / Senha: joao123
-- ============================================================
INSERT INTO usuarios (nome, telefone, cpf, endereco, setor, cargo, email, usuario, senha, tipo, salario_base, vale_transporte, vale_refeicao)
VALUES (
    'João Silva',
    '(11) 99999-1234',
    '123.456.789-00',
    'Rua das Flores, 123 - São Paulo/SP',
    'TI',
    'Desenvolvedor',
    'joao@empresa.com',
    'joao',
    '$2y$10$6Ezrdqn.FKQILuppsjQ5ReISOiGTZiKJSqjFX0hs9B2ipOg4gBMve',
    'funcionario',
    3500.00,
    220.00,
    550.00
);

-- ============================================================
-- Índices para melhorar performance das consultas
-- ============================================================
CREATE INDEX idx_ponto_usuario ON registros_ponto(usuario_id);
CREATE INDEX idx_ponto_data ON registros_ponto(data_referencia);
CREATE INDEX idx_servicos_setor ON servicos(setor, cargo);
CREATE INDEX idx_servicos_status ON servicos_status(usuario_id, status);
