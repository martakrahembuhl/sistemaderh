<?php
/**
 * Página de Login - Sistema RH
 * Processa autenticação e redireciona por tipo de usuário
 */
session_start();

// Se já estiver logado, redireciona para o dashboard correto
if (isset($_SESSION['usuario_id'])) {
    if ($_SESSION['tipo'] === 'admin') {
        header('Location: admin/index.php');
    } else {
        header('Location: funcionario/index.php');
    }
    exit;
}

// Inclui a conexão com o banco
require_once 'config/db.php';

$erro = '';

// Processa o formulário de login (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? '');
    $senha   = trim($_POST['senha']   ?? '');

    if (empty($usuario) || empty($senha)) {
        $erro = 'Preencha o usuário e a senha.';
    } else {
        // Busca o usuário no banco usando prepared statement (segurança)
        $stmt = $conn->prepare("SELECT id, nome, usuario, senha, tipo, setor, cargo FROM usuarios WHERE usuario = ? LIMIT 1");
        $stmt->bind_param('s', $usuario);
        $stmt->execute();
        $result = $stmt->get_result();
        $user   = $result->fetch_assoc();
        $stmt->close();

        // Verifica se o usuário existe e a senha está correta
        if ($user && password_verify($senha, $user['senha'])) {
            // Cria a sessão com os dados do usuário
            $_SESSION['usuario_id'] = $user['id'];
            $_SESSION['nome']       = $user['nome'];
            $_SESSION['usuario']    = $user['usuario'];
            $_SESSION['tipo']       = $user['tipo'];
            $_SESSION['setor']      = $user['setor'];
            $_SESSION['cargo']      = $user['cargo'];

            // Redireciona conforme o tipo
            if ($user['tipo'] === 'admin') {
                header('Location: admin/index.php');
            } else {
                header('Location: funcionario/index.php');
            }
            exit;
        } else {
            $erro = 'Usuário ou senha incorretos.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema RH</title>
    <style>
        /* Estilos inline para não depender de arquivos externos */
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1e3a5f 0%, #2d5986 50%, #1a73e8 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-wrapper {
            width: 100%;
            max-width: 420px;
        }
        .login-logo {
            text-align: center;
            margin-bottom: 28px;
            color: #fff;
        }
        .login-logo .logo-icon {
            font-size: 3.5rem;
            display: block;
            margin-bottom: 10px;
        }
        .login-logo h1 {
            font-size: 1.8rem;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .login-logo p {
            font-size: 0.9rem;
            color: rgba(255,255,255,0.75);
            margin-top: 4px;
        }
        .login-card {
            background: #fff;
            border-radius: 12px;
            padding: 36px 32px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.25);
        }
        .login-card h2 {
            font-size: 1.2rem;
            color: #343a40;
            margin-bottom: 24px;
            font-weight: 600;
        }
        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: block;
            font-size: 0.85rem;
            font-weight: 600;
            color: #343a40;
            margin-bottom: 6px;
        }
        .form-control {
            width: 100%;
            padding: 11px 14px;
            border: 1.5px solid #ced4da;
            border-radius: 7px;
            font-size: 0.95rem;
            color: #343a40;
            transition: border-color 0.2s, box-shadow 0.2s;
            font-family: inherit;
        }
        .form-control:focus {
            outline: none;
            border-color: #1a73e8;
            box-shadow: 0 0 0 3px rgba(26,115,232,0.15);
        }
        .btn-login {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #1a73e8, #1557b0);
            color: #fff;
            border: none;
            border-radius: 7px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.2s, transform 0.1s;
            margin-top: 8px;
            font-family: inherit;
        }
        .btn-login:hover { opacity: 0.92; }
        .btn-login:active { transform: scale(0.98); }
        .alert-error {
            background: #fce8e6;
            color: #b71c1c;
            border-left: 4px solid #dc3545;
            padding: 11px 14px;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .login-footer {
            text-align: center;
            margin-top: 20px;
            color: rgba(255,255,255,0.7);
            font-size: 0.8rem;
        }
        .demo-info {
            background: rgba(255,255,255,0.12);
            border-radius: 8px;
            padding: 14px 16px;
            margin-top: 20px;
            color: rgba(255,255,255,0.9);
            font-size: 0.82rem;
        }
        .demo-info strong { display: block; margin-bottom: 6px; color: #fff; }
        .demo-info code {
            background: rgba(255,255,255,0.2);
            padding: 2px 6px;
            border-radius: 4px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <!-- Logo e título -->
        <div class="login-logo">
            <span class="logo-icon">🏢</span>
            <h1>Sistema RH</h1>
            <p>Gestão de Recursos Humanos</p>
        </div>

        <!-- Card de login -->
        <div class="login-card">
            <h2>Acesse sua conta</h2>

            <!-- Exibe erro se houver -->
            <?php if ($erro): ?>
                <div class="alert-error">
                    <span>⚠️</span>
                    <span><?= htmlspecialchars($erro) ?></span>
                </div>
            <?php endif; ?>

            <!-- Formulário de login -->
            <form method="POST" action="">
                <div class="form-group">
                    <label for="usuario">👤 Usuário</label>
                    <input
                        type="text"
                        id="usuario"
                        name="usuario"
                        class="form-control"
                        placeholder="Digite seu usuário"
                        value="<?= htmlspecialchars($_POST['usuario'] ?? '') ?>"
                        required
                        autocomplete="username"
                    >
                </div>

                <div class="form-group">
                    <label for="senha">🔒 Senha</label>
                    <input
                        type="password"
                        id="senha"
                        name="senha"
                        class="form-control"
                        placeholder="Digite sua senha"
                        required
                        autocomplete="current-password"
                    >
                </div>

                <button type="submit" class="btn-login">
                    🚀 Entrar no Sistema
                </button>
            </form>
        </div>

        <!-- Informações de demonstração -->
        <div class="demo-info">
            <strong>🔑 Acessos de demonstração:</strong>
            Admin: <code>admin</code> / <code>admin123</code><br>
            Funcionário: <code>joao</code> / <code>joao123</code>
        </div>

        <div class="login-footer">
            Sistema RH &copy; <?= date('Y') ?> — Versão Didática
        </div>
    </div>
</body>
</html>
