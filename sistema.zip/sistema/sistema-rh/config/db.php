<?php
// ============================================================
// Configuração da conexão com o banco de dados
// Altere as constantes abaixo conforme seu ambiente
// ============================================================

define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'sistema_rh');

// Cria a conexão com o banco usando MySQLi
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Define o charset para suportar caracteres especiais (acentos, etc.)
$conn->set_charset('utf8mb4');

// Verifica se houve erro na conexão
if ($conn->connect_error) {
    // Em produção, não exiba detalhes do erro para o usuário
    die(json_encode(['error' => 'Conexão falhou: ' . $conn->connect_error]));
}
