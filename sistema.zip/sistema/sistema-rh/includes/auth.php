<?php
// ============================================================
// Funções de autenticação e controle de acesso
// ============================================================

/**
 * Verifica se o usuário está logado.
 * Se não estiver, redireciona para o login.
 */
function verificarLogin() {
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

/**
 * Verifica se o usuário logado é administrador.
 * Se não for, redireciona para o dashboard do funcionário.
 */
function verificarAdmin() {
    verificarLogin();
    if ($_SESSION['tipo'] !== 'admin') {
        header('Location: ' . BASE_URL . '/funcionario/index.php');
        exit;
    }
}

/**
 * Verifica se o usuário logado é funcionário.
 * Se for admin, redireciona para o dashboard admin.
 */
function verificarFuncionario() {
    verificarLogin();
    if ($_SESSION['tipo'] !== 'funcionario') {
        header('Location: ' . BASE_URL . '/admin/index.php');
        exit;
    }
}

/**
 * Retorna os dados do usuário logado da sessão.
 * @return array Dados do usuário (id, nome, tipo, setor, cargo)
 */
function getUsuarioLogado() {
    return [
        'id'    => $_SESSION['usuario_id'] ?? null,
        'nome'  => $_SESSION['nome']       ?? '',
        'tipo'  => $_SESSION['tipo']       ?? '',
        'setor' => $_SESSION['setor']      ?? '',
        'cargo' => $_SESSION['cargo']      ?? '',
    ];
}
