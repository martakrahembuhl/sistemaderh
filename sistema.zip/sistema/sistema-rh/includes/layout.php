<?php
/**
 * Funções de layout reutilizáveis
 * Gera sidebar e topbar para admin e funcionário
 */

/**
 * Renderiza a sidebar do administrador
 * @param string $paginaAtiva Nome da página ativa para destacar no menu
 */
function renderSidebarAdmin($paginaAtiva = '') {
    $usuario = getUsuarioLogado();
    $links = [
        'dashboard'    => ['url' => 'index.php',        'icon' => '📊', 'label' => 'Dashboard'],
        'funcionarios' => ['url' => 'funcionarios.php', 'icon' => '👥', 'label' => 'Funcionários'],
        'correcoes'    => ['url' => 'correcoes.php',    'icon' => '✏️',  'label' => 'Correções de Ponto'],
        'servicos'     => ['url' => 'servicos.php',     'icon' => '📋', 'label' => 'Serviços'],
    ];
    renderSidebar($usuario, $links, $paginaAtiva, 'Administrador');
}

/**
 * Renderiza a sidebar do funcionário
 * @param string $paginaAtiva Nome da página ativa para destacar no menu
 */
function renderSidebarFuncionario($paginaAtiva = '') {
    $usuario = getUsuarioLogado();
    $links = [
        'dashboard' => ['url' => 'index.php',    'icon' => '🏠', 'label' => 'Dashboard'],
        'ponto'     => ['url' => 'ponto.php',    'icon' => '⏱️',  'label' => 'Registro de Ponto'],
        'folha'     => ['url' => 'folha.php',    'icon' => '💰', 'label' => 'Folha de Pagamento'],
        'servicos'  => ['url' => 'servicos.php', 'icon' => '📋', 'label' => 'Meus Serviços'],
    ];
    renderSidebar($usuario, $links, $paginaAtiva, 'Funcionário');
}

/**
 * Renderiza a sidebar genérica
 */
function renderSidebar($usuario, $links, $paginaAtiva, $tipoLabel) {
    $iniciais = mb_strtoupper(mb_substr($usuario['nome'], 0, 1));
    echo '<div class="sidebar-overlay" onclick="toggleSidebar()"></div>';
    echo '<aside class="sidebar">';
    echo '  <div class="sidebar-brand">';
    echo '    <h2>🏢 Sistema RH</h2>';
    echo '    <span>' . htmlspecialchars($tipoLabel) . '</span>';
    echo '  </div>';
    echo '  <div class="sidebar-user">';
    echo '    <div class="avatar">' . $iniciais . '</div>';
    echo '    <div class="user-info">';
    echo '      <div class="user-name">' . htmlspecialchars($usuario['nome']) . '</div>';
    echo '      <div class="user-role">' . htmlspecialchars($usuario['cargo'] ?: $tipoLabel) . '</div>';
    echo '    </div>';
    echo '  </div>';
    echo '  <nav class="sidebar-nav">';
    echo '    <div class="nav-section">Menu</div>';
    foreach ($links as $key => $link) {
        $ativo = ($paginaAtiva === $key) ? ' active' : '';
        echo '    <a href="' . $link['url'] . '" class="' . trim($ativo) . '">';
        echo '      <span class="icon">' . $link['icon'] . '</span>';
        echo '      ' . $link['label'];
        echo '    </a>';
    }
    echo '  </nav>';
    echo '  <div class="sidebar-footer">';
    echo '    <a href="../logout.php">🚪 Sair do Sistema</a>';
    echo '  </div>';
    echo '</aside>';
}

/**
 * Renderiza a topbar
 * @param string $titulo Título da página
 */
function renderTopbar($titulo) {
    echo '<header class="topbar">';
    echo '  <div class="d-flex align-center gap-2">';
    echo '    <button class="sidebar-toggle" onclick="toggleSidebar()">☰</button>';
    echo '    <h1>' . htmlspecialchars($titulo) . '</h1>';
    echo '  </div>';
    echo '  <div class="topbar-right">';
    echo '    <span class="date-time" id="topbar-time"></span>';
    echo '  </div>';
    echo '</header>';
}

/**
 * Exibe alertas de sessão (mensagens de sucesso/erro após redirect)
 */
function exibirAlertas() {
    if (isset($_SESSION['msg_sucesso'])) {
        echo '<div class="alert alert-success" data-auto-dismiss="4000">';
        echo '  <span>✅</span><span>' . htmlspecialchars($_SESSION['msg_sucesso']) . '</span>';
        echo '  <button class="close-btn">×</button>';
        echo '</div>';
        unset($_SESSION['msg_sucesso']);
    }
    if (isset($_SESSION['msg_erro'])) {
        echo '<div class="alert alert-danger" data-auto-dismiss="5000">';
        echo '  <span>❌</span><span>' . htmlspecialchars($_SESSION['msg_erro']) . '</span>';
        echo '  <button class="close-btn">×</button>';
        echo '</div>';
        unset($_SESSION['msg_erro']);
    }
}
