<?php
// ============================================================
// Funções auxiliares do Sistema RH
// ============================================================

/**
 * Calcula as horas trabalhadas com base nos registros de ponto.
 * Considera entrada, saída e intervalo de almoço.
 *
 * @param string|null $entrada       Horário de entrada (HH:MM:SS)
 * @param string|null $saida         Horário de saída (HH:MM:SS)
 * @param string|null $almoco_saida  Horário de saída para almoço
 * @param string|null $almoco_retorno Horário de retorno do almoço
 * @return string Horas trabalhadas no formato HH:MM
 */
function calcularHorasTrabalhadas($entrada, $saida, $almoco_saida = null, $almoco_retorno = null) {
    // Se não tiver entrada ou saída, retorna zero
    if (!$entrada || !$saida) {
        return '00:00';
    }

    // Converte os horários para timestamps (usando data fictícia)
    $ts_entrada = strtotime("2000-01-01 $entrada");
    $ts_saida   = strtotime("2000-01-01 $saida");

    // Calcula o total de segundos trabalhados
    $total_segundos = $ts_saida - $ts_entrada;

    // Desconta o intervalo de almoço, se registrado
    if ($almoco_saida && $almoco_retorno) {
        $ts_almoco_saida   = strtotime("2000-01-01 $almoco_saida");
        $ts_almoco_retorno = strtotime("2000-01-01 $almoco_retorno");
        $intervalo = $ts_almoco_retorno - $ts_almoco_saida;
        $total_segundos -= $intervalo;
    }

    // Evita valores negativos
    if ($total_segundos < 0) {
        return '00:00';
    }

    // Converte segundos para horas e minutos
    $horas   = floor($total_segundos / 3600);
    $minutos = floor(($total_segundos % 3600) / 60);

    return sprintf('%02d:%02d', $horas, $minutos);
}

/**
 * Formata um CPF para o padrão XXX.XXX.XXX-XX.
 *
 * @param string $cpf CPF apenas com números
 * @return string CPF formatado
 */
function formatarCPF($cpf) {
    // Remove tudo que não for número
    $cpf = preg_replace('/\D/', '', $cpf);

    if (strlen($cpf) !== 11) {
        return $cpf; // Retorna sem formatação se inválido
    }

    return substr($cpf, 0, 3) . '.' .
           substr($cpf, 3, 3) . '.' .
           substr($cpf, 6, 3) . '-' .
           substr($cpf, 9, 2);
}

/**
 * Formata um telefone para o padrão (XX) XXXXX-XXXX ou (XX) XXXX-XXXX.
 *
 * @param string $telefone Telefone apenas com números
 * @return string Telefone formatado
 */
function formatarTelefone($telefone) {
    // Remove tudo que não for número
    $tel = preg_replace('/\D/', '', $telefone);

    if (strlen($tel) === 11) {
        // Celular: (XX) XXXXX-XXXX
        return '(' . substr($tel, 0, 2) . ') ' .
               substr($tel, 2, 5) . '-' .
               substr($tel, 7, 4);
    } elseif (strlen($tel) === 10) {
        // Fixo: (XX) XXXX-XXXX
        return '(' . substr($tel, 0, 2) . ') ' .
               substr($tel, 2, 4) . '-' .
               substr($tel, 6, 4);
    }

    return $telefone; // Retorna sem formatação se inválido
}

/**
 * Calcula a folha de pagamento de um funcionário para um mês/ano.
 * Inclui INSS, IRRF, benefícios e horas extras.
 *
 * @param array  $funcionario Dados do funcionário (salario_base, vale_transporte, vale_refeicao)
 * @param float  $horas_trabalhadas Total de horas trabalhadas no mês (em decimal)
 * @param int    $dias_uteis Dias úteis no mês
 * @return array Detalhamento da folha de pagamento
 */
function calcularFolhaPagamento($funcionario, $horas_trabalhadas_decimal, $dias_uteis = 22) {
    $salario_base    = (float) $funcionario['salario_base'];
    $vale_transporte = (float) $funcionario['vale_transporte'];
    $vale_refeicao   = (float) $funcionario['vale_refeicao'];

    // Horas esperadas no mês (8h/dia * dias úteis)
    $horas_esperadas = $dias_uteis * 8;

    // Calcula horas extras (acima de 8h/dia não é calculado aqui, apenas total)
    $horas_extras_decimal = max(0, $horas_trabalhadas_decimal - $horas_esperadas);
    $valor_hora           = $salario_base / ($dias_uteis * 8);
    $valor_horas_extras   = $horas_extras_decimal * $valor_hora * 1.5; // 50% adicional

    // Salário bruto
    $salario_bruto = $salario_base + $valor_horas_extras;

    // ---- Cálculo do INSS (tabela 2024) ----
    $inss = calcularINSS($salario_bruto);

    // ---- Base de cálculo do IRRF (salário bruto - INSS) ----
    $base_irrf = $salario_bruto - $inss;
    $irrf      = calcularIRRF($base_irrf);

    // ---- Totais ----
    $total_proventos  = $salario_bruto;
    $total_descontos  = $inss + $irrf;
    $total_beneficios = $vale_transporte + $vale_refeicao;
    $salario_liquido  = $total_proventos - $total_descontos + $total_beneficios;

    return [
        'salario_base'         => $salario_base,
        'horas_extras_decimal' => $horas_extras_decimal,
        'valor_horas_extras'   => $valor_horas_extras,
        'salario_bruto'        => $salario_bruto,
        'inss'                 => $inss,
        'irrf'                 => $irrf,
        'vale_transporte'      => $vale_transporte,
        'vale_refeicao'        => $vale_refeicao,
        'total_proventos'      => $total_proventos,
        'total_descontos'      => $total_descontos,
        'total_beneficios'     => $total_beneficios,
        'salario_liquido'      => $salario_liquido,
    ];
}

/**
 * Calcula o INSS com base na tabela progressiva 2024.
 *
 * @param float $salario Salário bruto
 * @return float Valor do INSS
 */
function calcularINSS($salario) {
    // Tabela INSS 2024 (progressiva)
    $faixas = [
        ['limite' => 1412.00,  'aliquota' => 0.075],
        ['limite' => 2666.68,  'aliquota' => 0.09],
        ['limite' => 4000.03,  'aliquota' => 0.12],
        ['limite' => 7786.02,  'aliquota' => 0.14],
    ];

    $inss       = 0;
    $base_calc  = $salario;
    $limite_ant = 0;

    foreach ($faixas as $faixa) {
        if ($base_calc <= 0) break;

        $faixa_valor = $faixa['limite'] - $limite_ant;
        $valor_calc  = min($base_calc, $faixa_valor);
        $inss       += $valor_calc * $faixa['aliquota'];
        $base_calc  -= $faixa_valor;
        $limite_ant  = $faixa['limite'];
    }

    return round($inss, 2);
}

/**
 * Calcula o IRRF com base na tabela 2024.
 *
 * @param float $base Base de cálculo (salário - INSS)
 * @return float Valor do IRRF
 */
function calcularIRRF($base) {
    // Tabela IRRF 2024
    if ($base <= 2259.20) {
        return 0;
    } elseif ($base <= 2826.65) {
        return round($base * 0.075 - 169.44, 2);
    } elseif ($base <= 3751.05) {
        return round($base * 0.15 - 381.44, 2);
    } elseif ($base <= 4664.68) {
        return round($base * 0.225 - 662.77, 2);
    } else {
        return round($base * 0.275 - 896.00, 2);
    }
}

/**
 * Converte horas no formato HH:MM para decimal.
 * Ex: "08:30" → 8.5
 *
 * @param string $horas Horas no formato HH:MM
 * @return float Horas em decimal
 */
function horasParaDecimal($horas) {
    if (!$horas || $horas === '00:00') return 0;
    list($h, $m) = explode(':', $horas);
    return (int)$h + ((int)$m / 60);
}

/**
 * Retorna o nome do mês em português.
 *
 * @param int $mes Número do mês (1-12)
 * @return string Nome do mês
 */
function nomeMes($mes) {
    $meses = [
        1 => 'Janeiro', 2 => 'Fevereiro', 3 => 'Março',
        4 => 'Abril',   5 => 'Maio',      6 => 'Junho',
        7 => 'Julho',   8 => 'Agosto',    9 => 'Setembro',
        10 => 'Outubro', 11 => 'Novembro', 12 => 'Dezembro'
    ];
    return $meses[(int)$mes] ?? '';
}

/**
 * Sanitiza uma string para evitar XSS.
 *
 * @param string $str String a sanitizar
 * @return string String sanitizada
 */
function sanitizar($str) {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}
