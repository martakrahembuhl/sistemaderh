<?php
/**
 * Dashboard do Administrador
 * Exibe resumo geral: funcionários, ponto do dia, serviços e correções
 */
session_start();
define('BASE_URL', '..');
require_once '../config/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/layout.php';

// Garante que apenas admins acessem esta página
verificarAdmin();

// ---- Consultas para os cards de resumo ----

// Total de funcionários ativos
$r = $conn->query("SELECT COUNT(*) as total FROM usuarios WHERE tipo = 'funcionario'");
$totalFuncionarios = $r->fetch_assoc()['total'];

// Registros de ponto feitos hoje
$hoje = date('Y-m-d');
$r = $conn->query("SELECT COUNT(*) as total FROM registros_ponto WHERE data_referencia = '$hoje'");
$registrosHoje = $r->fetch_assoc()['total'];

// Serviços com status ativo
$r = $conn->query("SELECT COUNT(*) as total FROM servicos WHERE status_geral = 'ativo'");
$servicosAtivos = $r->fetch_assoc()['total'];

// Correções realizadas este mês
$mesAtual = date('Y-m');
$r = $conn->query("SELECT COUNT(*) as total FROM correcoes_ponto WHERE DATE_FORMAT(created_at, '%Y-%m') = '$mesAtual'");
$correcoesmes = $r->fetch_assoc()['total'];

// ---- Últimos registros de ponto do dia ----
$stmt = $conn->prepare("
    SELECT rp.tipo, rp.data_hora, u.nome, u.setor, u.cargo
    FROM registros_ponto rp
    INNER JOIN usuarios u ON u.id = rp.usuario_id
    WHERE rp.data_referencia = ?
    ORDER BY rp.data_hora DESC
    LIMIT 20
");
$stmt->bind_param('s', $hoje);
$stmt->execute();
$registros = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// ---- Funcionários que ainda não bateram ponto hoje ----
$stmt = $conn->prepare("
    SELECT u.nome, u.setor, u.cargo
    FROM usuarios u
    WHERE u.tipo = 'funcionario'
      AND u.id NOT IN (
          SELECT DISTINCT usuario_id FROM registros_ponto WHERE data_referencia = ?
      )
    ORDER BY u.nome
");
$stmt->bind_param('s', $hoje);
$stmt->execute();
$semPonto = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$tipoLabels = [
    'entrada'        => ['label' => 'Entrada',         'badge' => 'badge-entrada'],
    'saida'          => ['label' => 'Saída',            'badge' => 'badge-saida'],
    'almoco_saida'   => ['label' => 'Saída Almoço',     'badge' => 'badge-almoco'],
    'almoco_retorno' => ['label' => 'Retorno Almoço',   'badge' => 'badge-almoco'],
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Sistema RH</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="wrapper">
    <?php renderSidebarAdmin('dashboard'); ?>

    <div class="main-content">
        <?php renderTopbar('Dashboard Administrativo'); ?>

        <div class="content">
            <div id="alerts-container"><?php exibirAlertas(); ?></div>

            <!-- Cards de resumo -->
            <div class="cards-grid">
                <div class="card">
                    <div class="card-icon blue">👥</div>
                    <div class="card-info">
                        <div class="card-value"><?= $totalFuncionarios ?></div>
                        <div class="card-label">Funcionários</div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon green">⏱️</div>
                    <div class="card-info">
                        <div class="card-value"><?= $registrosHoje ?></div>
                        <div class="card-label">Registros Hoje</div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon yellow">📋</div>
                    <div class="card-info">
                        <div class="card-value"><?= $servicosAtivos ?></div>
                        <div class="card-label">Serviços Ativos</div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon cyan">✏️</div>
                    <div class="card-info">
                        <div class="card-value"><?= $correcoesmes ?></div>
                        <div class="card-label">Correções no Mês</div>
                    </div>
                </div>
            </div>

            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:24px; flex-wrap:wrap;">

                <!-- Últimos registros de ponto -->
                <div class="panel" style="grid-column: 1 / -1;">
                    <div class="panel-header">
                        <h3>⏱️ Registros de Ponto Hoje — <?= date('d/m/Y') ?></h3>
                        <a href="correcoes.php" class="btn btn-sm btn-outline btn-primary">Ver Todos</a>
                    </div>
                    <?php if (empty($registros)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">📭</div>
                            <p>Nenhum registro de ponto hoje.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Funcionário</th>
                                        <th>Setor</th>
                                        <th>Cargo</th>
                                        <th>Tipo</th>
                                        <th>Horário</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($registros as $reg): ?>
                                        <tr>
                                            <td><strong><?= sanitizar($reg['nome']) ?></strong></td>
                                            <td><?= sanitizar($reg['setor']) ?></td>
                                            <td><?= sanitizar($reg['cargo']) ?></td>
                                            <td>
                                                <span class="badge <?= $tipoLabels[$reg['tipo']]['badge'] ?? 'badge-secondary' ?>">
                                                    <?= $tipoLabels[$reg['tipo']]['label'] ?? $reg['tipo'] ?>
                                                </span>
                                            </td>
                                            <td><?= date('H:i', strtotime($reg['data_hora'])) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Funcionários sem ponto hoje -->
                <div class="panel">
                    <div class="panel-header">
                        <h3>⚠️ Sem Ponto Hoje</h3>
                        <span class="badge badge-warning"><?= count($semPonto) ?></span>
                    </div>
                    <?php if (empty($semPonto)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">✅</div>
                            <p>Todos registraram ponto hoje!</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr><th>Nome</th><th>Setor</th><th>Cargo</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($semPonto as $f): ?>
                                        <tr>
                                            <td><?= sanitizar($f['nome']) ?></td>
                                            <td><?= sanitizar($f['setor']) ?></td>
                                            <td><?= sanitizar($f['cargo']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Acesso rápido -->
                <div class="panel">
                    <div class="panel-header"><h3>🚀 Acesso Rápido</h3></div>
                    <div class="panel-body" style="display:flex; flex-direction:column; gap:10px;">
                        <a href="funcionarios.php" class="btn btn-primary">👥 Gerenciar Funcionários</a>
                        <a href="correcoes.php"    class="btn btn-warning">✏️ Corrigir Ponto</a>
                        <a href="servicos.php"     class="btn btn-info">📋 Gerenciar Serviços</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<script src="../assets/js/main.js"></script>
</body>
</html>
