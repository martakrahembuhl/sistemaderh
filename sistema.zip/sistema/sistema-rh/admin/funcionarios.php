<?php
/**
 * Gerenciamento de Funcionários (Admin)
 * CRUD completo: listar, cadastrar, editar, excluir
 */
session_start();
define('BASE_URL', '..');
require_once '../config/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/layout.php';

verificarAdmin();

$acao  = $_GET['acao']  ?? '';
$id    = (int)($_GET['id'] ?? 0);
$erro  = '';
$sucesso = '';

// ============================================================
// Processar ações POST (cadastrar / editar / excluir)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao_post = $_POST['acao'] ?? '';

    if ($acao_post === 'salvar') {
        // Coleta e sanitiza os dados do formulário
        $nome            = trim($_POST['nome']            ?? '');
        $telefone        = trim($_POST['telefone']        ?? '');
        $cpf             = trim($_POST['cpf']             ?? '');
        $endereco        = trim($_POST['endereco']        ?? '');
        $setor           = trim($_POST['setor']           ?? '');
        $cargo           = trim($_POST['cargo']           ?? '');
        $email           = trim($_POST['email']           ?? '');
        $usuario_login   = trim($_POST['usuario_login']   ?? '');
        $senha           = trim($_POST['senha']           ?? '');
        $tipo            = trim($_POST['tipo']            ?? 'funcionario');
        $salario_base    = (float)str_replace(',', '.', $_POST['salario_base']    ?? 0);
        $vale_transporte = (float)str_replace(',', '.', $_POST['vale_transporte'] ?? 0);
        $vale_refeicao   = (float)str_replace(',', '.', $_POST['vale_refeicao']   ?? 0);
        $edit_id         = (int)($_POST['edit_id'] ?? 0);

        // Validação básica
        if (empty($nome) || empty($usuario_login)) {
            $erro = 'Nome e usuário são obrigatórios.';
        } else {
            if ($edit_id > 0) {
                // ---- EDITAR funcionário existente ----
                if (!empty($senha)) {
                    // Atualiza com nova senha
                    $hash = password_hash($senha, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("
                        UPDATE usuarios SET nome=?, telefone=?, cpf=?, endereco=?, setor=?, cargo=?,
                        email=?, usuario=?, senha=?, tipo=?, salario_base=?, vale_transporte=?, vale_refeicao=?
                        WHERE id=?
                    ");
                    $stmt->bind_param('ssssssssssdddi',
                        $nome, $telefone, $cpf, $endereco, $setor, $cargo,
                        $email, $usuario_login, $hash, $tipo,
                        $salario_base, $vale_transporte, $vale_refeicao, $edit_id
                    );
                } else {
                    // Mantém a senha atual
                    $stmt = $conn->prepare("
                        UPDATE usuarios SET nome=?, telefone=?, cpf=?, endereco=?, setor=?, cargo=?,
                        email=?, usuario=?, tipo=?, salario_base=?, vale_transporte=?, vale_refeicao=?
                        WHERE id=?
                    ");
                    $stmt->bind_param('ssssssssddddi',
                        $nome, $telefone, $cpf, $endereco, $setor, $cargo,
                        $email, $usuario_login, $tipo,
                        $salario_base, $vale_transporte, $vale_refeicao, $edit_id
                    );
                }
                if ($stmt->execute()) {
                    $_SESSION['msg_sucesso'] = 'Funcionário atualizado com sucesso!';
                } else {
                    $_SESSION['msg_erro'] = 'Erro ao atualizar: ' . $conn->error;
                }
                $stmt->close();
            } else {
                // ---- CADASTRAR novo funcionário ----
                if (empty($senha)) {
                    $erro = 'A senha é obrigatória para novos funcionários.';
                } else {
                    $hash = password_hash($senha, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("
                        INSERT INTO usuarios (nome, telefone, cpf, endereco, setor, cargo, email, usuario, senha, tipo, salario_base, vale_transporte, vale_refeicao)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->bind_param('ssssssssssddd',
                        $nome, $telefone, $cpf, $endereco, $setor, $cargo,
                        $email, $usuario_login, $hash, $tipo,
                        $salario_base, $vale_transporte, $vale_refeicao
                    );
                    if ($stmt->execute()) {
                        $_SESSION['msg_sucesso'] = 'Funcionário cadastrado com sucesso!';
                    } else {
                        // Verifica duplicidade de CPF ou usuário
                        if ($conn->errno === 1062) {
                            $_SESSION['msg_erro'] = 'CPF ou usuário já cadastrado no sistema.';
                        } else {
                            $_SESSION['msg_erro'] = 'Erro ao cadastrar: ' . $conn->error;
                        }
                    }
                    $stmt->close();
                }
            }
            if (empty($erro)) {
                header('Location: funcionarios.php');
                exit;
            }
        }
    }

    if ($acao_post === 'excluir') {
        $del_id = (int)($_POST['del_id'] ?? 0);
        // Não permite excluir o próprio admin logado
        if ($del_id === (int)$_SESSION['usuario_id']) {
            $_SESSION['msg_erro'] = 'Você não pode excluir sua própria conta.';
        } else {
            $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
            $stmt->bind_param('i', $del_id);
            if ($stmt->execute()) {
                $_SESSION['msg_sucesso'] = 'Funcionário excluído com sucesso.';
            } else {
                $_SESSION['msg_erro'] = 'Erro ao excluir funcionário.';
            }
            $stmt->close();
        }
        header('Location: funcionarios.php');
        exit;
    }
}

// ---- Busca dados para edição ----
$editando = null;
if ($acao === 'editar' && $id > 0) {
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $editando = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// ---- Lista todos os funcionários ----
$funcionarios = $conn->query("SELECT * FROM usuarios ORDER BY tipo, nome")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Funcionários - Sistema RH</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="wrapper">
    <?php renderSidebarAdmin('funcionarios'); ?>

    <div class="main-content">
        <?php renderTopbar('Gerenciamento de Funcionários'); ?>

        <div class="content">
            <div id="alerts-container"><?php exibirAlertas(); ?></div>
            <?php if ($erro): ?>
                <div class="alert alert-danger"><span>❌</span><span><?= sanitizar($erro) ?></span></div>
            <?php endif; ?>

            <!-- Botão novo funcionário -->
            <div class="d-flex" style="justify-content:flex-end; margin-bottom:16px;">
                <button class="btn btn-success" onclick="abrirModal('modal-funcionario')">
                    ➕ Novo Funcionário
                </button>
            </div>

            <!-- Tabela de funcionários -->
            <div class="panel">
                <div class="panel-header">
                    <h3>👥 Lista de Funcionários (<?= count($funcionarios) ?>)</h3>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nome</th>
                                <th>CPF</th>
                                <th>Setor</th>
                                <th>Cargo</th>
                                <th>Email</th>
                                <th>Tipo</th>
                                <th>Salário Base</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($funcionarios as $f): ?>
                                <tr>
                                    <td><?= $f['id'] ?></td>
                                    <td><strong><?= sanitizar($f['nome']) ?></strong></td>
                                    <td><?= sanitizar($f['cpf'] ?: '—') ?></td>
                                    <td><?= sanitizar($f['setor'] ?: '—') ?></td>
                                    <td><?= sanitizar($f['cargo'] ?: '—') ?></td>
                                    <td><?= sanitizar($f['email'] ?: '—') ?></td>
                                    <td>
                                        <span class="badge <?= $f['tipo'] === 'admin' ? 'badge-primary' : 'badge-success' ?>">
                                            <?= $f['tipo'] === 'admin' ? '🔑 Admin' : '👤 Funcionário' ?>
                                        </span>
                                    </td>
                                    <td>R$ <?= number_format($f['salario_base'], 2, ',', '.') ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary"
                                            onclick="editarFuncionario(<?= htmlspecialchars(json_encode($f)) ?>)">
                                            ✏️ Editar
                                        </button>
                                        <?php if ($f['id'] != $_SESSION['usuario_id']): ?>
                                            <form method="POST" style="display:inline;"
                                                onsubmit="return confirmarExclusao('Excluir <?= sanitizar($f['nome']) ?>?')">
                                                <input type="hidden" name="acao"   value="excluir">
                                                <input type="hidden" name="del_id" value="<?= $f['id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-danger">🗑️ Excluir</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Cadastro/Edição -->
<div class="modal-overlay" id="modal-funcionario">
    <div class="modal">
        <div class="modal-header">
            <h4 id="modal-titulo">➕ Novo Funcionário</h4>
            <button class="modal-close" onclick="fecharModal('modal-funcionario')">×</button>
        </div>
        <form method="POST" id="form-funcionario" onsubmit="return validarFormulario('form-funcionario')">
            <div class="modal-body">
                <input type="hidden" name="acao"    value="salvar">
                <input type="hidden" name="edit_id" id="edit_id" value="0">

                <div class="form-row">
                    <div class="form-group">
                        <label>Nome Completo *</label>
                        <input type="text" name="nome" id="f_nome" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>CPF</label>
                        <input type="text" name="cpf" id="f_cpf" class="form-control" data-mask="cpf" placeholder="000.000.000-00">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Telefone</label>
                        <input type="text" name="telefone" id="f_telefone" class="form-control" data-mask="telefone" placeholder="(00) 00000-0000">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" id="f_email" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label>Endereço</label>
                    <input type="text" name="endereco" id="f_endereco" class="form-control">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Setor</label>
                        <input type="text" name="setor" id="f_setor" class="form-control" placeholder="Ex: TI, RH, Financeiro">
                    </div>
                    <div class="form-group">
                        <label>Cargo</label>
                        <input type="text" name="cargo" id="f_cargo" class="form-control" placeholder="Ex: Desenvolvedor">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Usuário (login) *</label>
                        <input type="text" name="usuario_login" id="f_usuario" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Tipo</label>
                        <select name="tipo" id="f_tipo" class="form-control">
                            <option value="funcionario">Funcionário</option>
                            <option value="admin">Administrador</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Senha <span id="senha-hint" class="text-muted">(obrigatória para novo)</span></label>
                        <input type="password" name="senha" id="f_senha" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Confirmar Senha</label>
                        <input type="password" name="senha_confirm" id="f_senha2" class="form-control">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Salário Base (R$)</label>
                        <input type="number" name="salario_base" id="f_salario" class="form-control" step="0.01" min="0" value="0">
                    </div>
                    <div class="form-group">
                        <label>Vale Transporte (R$)</label>
                        <input type="number" name="vale_transporte" id="f_vt" class="form-control" step="0.01" min="0" value="0">
                    </div>
                    <div class="form-group">
                        <label>Vale Refeição (R$)</label>
                        <input type="number" name="vale_refeicao" id="f_vr" class="form-control" step="0.01" min="0" value="0">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modal-funcionario')">Cancelar</button>
                <button type="submit" class="btn btn-success">💾 Salvar</button>
            </div>
        </form>
    </div>
</div>

<script src="../assets/js/main.js"></script>
<script>
// Preenche o modal com dados do funcionário para edição
function editarFuncionario(f) {
    document.getElementById('modal-titulo').textContent = '✏️ Editar Funcionário';
    document.getElementById('edit_id').value    = f.id;
    document.getElementById('f_nome').value     = f.nome     || '';
    document.getElementById('f_cpf').value      = f.cpf      || '';
    document.getElementById('f_telefone').value = f.telefone || '';
    document.getElementById('f_email').value    = f.email    || '';
    document.getElementById('f_endereco').value = f.endereco || '';
    document.getElementById('f_setor').value    = f.setor    || '';
    document.getElementById('f_cargo').value    = f.cargo    || '';
    document.getElementById('f_usuario').value  = f.usuario  || '';
    document.getElementById('f_tipo').value     = f.tipo     || 'funcionario';
    document.getElementById('f_salario').value  = f.salario_base    || 0;
    document.getElementById('f_vt').value       = f.vale_transporte || 0;
    document.getElementById('f_vr').value       = f.vale_refeicao   || 0;
    document.getElementById('f_senha').value    = '';
    document.getElementById('f_senha2').value   = '';
    document.getElementById('senha-hint').textContent = '(deixe em branco para manter)';
    abrirModal('modal-funcionario');
}

// Reseta o modal para novo cadastro
document.querySelector('[onclick="abrirModal(\'modal-funcionario\')"]')?.addEventListener('click', function() {
    document.getElementById('modal-titulo').textContent = '➕ Novo Funcionário';
    document.getElementById('form-funcionario').reset();
    document.getElementById('edit_id').value = '0';
    document.getElementById('senha-hint').textContent = '(obrigatória para novo)';
});
</script>
</body>
</html>
