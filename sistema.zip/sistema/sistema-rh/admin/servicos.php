<?php
/**
 * Gerenciamento de Serviços (Admin)
 * Criar, listar e acompanhar serviços por setor/cargo
 */
session_start();
define('BASE_URL', '..');
require_once '../config/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/layout.php';

verificarAdmin();

$adminId = $_SESSION['usuario_id'];

// ---- Processar ações POST ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'criar_servico') {
        $titulo    = trim($_POST['titulo']    ?? '');
        $descricao = trim($_POST['descricao'] ?? '');
        $setor     = trim($_POST['setor']     ?? '');
        $cargo     = trim($_POST['cargo']     ?? '');
        $prioridade = $_POST['prioridade']    ?? 'media';

        if ($titulo && $setor) {
            $stmt = $conn->prepare("INSERT INTO servicos (titulo, descricao, setor, cargo, prioridade, criado_por) VALUES (?,?,?,?,?,?)");
            $stmt->bind_param('sssssi', $titulo, $descricao, $setor, $cargo, $prioridade, $adminId);
            if ($stmt->execute()) {
                $servicoId = $conn->insert_id;
                // Cria status "pendente" para todos os funcionários do setor/cargo
                $sqlFunc = "SELECT id FROM usuarios WHERE tipo='funcionario' AND setor=?";
                $params  = [$setor];
                $types   = 's';
                if ($cargo) {
                    $sqlFunc .= " AND cargo=?";
                    $params[] = $cargo;
                    $types   .= 's';
                }
                $stmtF = $conn->prepare($sqlFunc);
                $stmtF->bind_param($types, ...$params);
                $stmtF->execute();
                $funcs = $stmtF->get_result()->fetch_all(MYSQLI_ASSOC);
                $stmtF->close();

                foreach ($funcs as $f) {
                    $stmtS = $conn->prepare("INSERT IGNORE INTO servicos_status (servico_id, usuario_id, status) VALUES (?,?,'pendente')");
                    $stmtS->bind_param('ii', $servicoId, $f['id']);
                    $stmtS->execute();
                    $stmtS->close();
                }
                $_SESSION['msg_sucesso'] = 'Serviço criado e atribuído com sucesso!';
            } else {
                $_SESSION['msg_erro'] = 'Erro ao criar serviço.';
            }
            $stmt->close();
        } else {
            $_SESSION['msg_erro'] = 'Título e setor são obrigatórios.';
        }
        header('Location: servicos.php');
        exit;
    }

    if ($acao === 'encerrar') {
        $sid = (int)$_POST['servico_id'];
        $stmt = $conn->prepare("UPDATE servicos SET status_geral='encerrado' WHERE id=?");
        $stmt->bind_param('i', $sid);
        $stmt->execute();
        $stmt->close();
        $_SESSION['msg_sucesso'] = 'Serviço encerrado.';
        header('Location: servicos.php');
        exit;
    }

    if ($acao === 'excluir') {
        $sid = (int)$_POST['servico_id'];
        $stmt = $conn->prepare("DELETE FROM servicos WHERE id=?");
        $stmt->bind_param('i', $sid);
        $stmt->execute();
        $stmt->close();
        $_SESSION['msg_sucesso'] = 'Serviço excluído.';
        header('Location: servicos.php');
        exit;
    }
}

// ---- Filtros ----
$filtroSetor     = $_GET['setor']      ?? '';
$filtroCargo     = $_GET['cargo']      ?? '';
$filtroPrioridade = $_GET['prioridade'] ?? '';
$filtroStatus    = $_GET['status']     ?? '';

// ---- Busca serviços com filtros ----
$sql = "SELECT s.*, u.nome as criador_nome FROM servicos s INNER JOIN usuarios u ON u.id = s.criado_por WHERE 1=1";
$params = [];
$types  = '';

if ($filtroSetor) {
    $sql .= " AND s.setor = ?";
    $params[] = $filtroSetor;
    $types   .= 's';
}
if ($filtroCargo) {
    $sql .= " AND s.cargo = ?";
    $params[] = $filtroCargo;
    $types   .= 's';
}
if ($filtroPrioridade) {
    $sql .= " AND s.prioridade = ?";
    $params[] = $filtroPrioridade;
    $types   .= 's';
}
if ($filtroStatus) {
    $sql .= " AND s.status_geral = ?";
    $params[] = $filtroStatus;
    $types   .= 's';
}
$sql .= " ORDER BY FIELD(s.prioridade,'urgente','alta','media','baixa'), s.created_at DESC";

if ($params) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $servicos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} else {
    $servicos = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);
}

// ---- Busca status de cada serviço por funcionário ----
$statusServicos = [];
if ($servicos) {
    $ids = implode(',', array_column($servicos, 'id'));
    $rows = $conn->query("
        SELECT ss.servico_id, ss.status, u.nome, u.id as usuario_id
        FROM servicos_status ss
        INNER JOIN usuarios u ON u.id = ss.usuario_id
        WHERE ss.servico_id IN ($ids)
        ORDER BY u.nome
    ")->fetch_all(MYSQLI_ASSOC);
    foreach ($rows as $r) {
        $statusServicos[$r['servico_id']][] = $r;
    }
}

// ---- Setores e cargos distintos para filtros ----
$setores = $conn->query("SELECT DISTINCT setor FROM usuarios WHERE setor IS NOT NULL AND setor != '' ORDER BY setor")->fetch_all(MYSQLI_ASSOC);
$cargos  = $conn->query("SELECT DISTINCT cargo  FROM usuarios WHERE cargo  IS NOT NULL AND cargo  != '' ORDER BY cargo")->fetch_all(MYSQLI_ASSOC);

$prioridadeBadge = [
    'urgente' => 'badge-urgente',
    'alta'    => 'badge-alta',
    'media'   => 'badge-media',
    'baixa'   => 'badge-baixa',
];
$statusBadge = [
    'pendente'    => 'badge-warning',
    'em_andamento'=> 'badge-info',
    'concluido'   => 'badge-success',
];
$statusLabel = [
    'pendente'    => '⏳ Pendente',
    'em_andamento'=> '🔄 Em Andamento',
    'concluido'   => '✅ Concluído',
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serviços - Sistema RH</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="wrapper">
    <?php renderSidebarAdmin('servicos'); ?>

    <div class="main-content">
        <?php renderTopbar('Gerenciamento de Serviços'); ?>

        <div class="content">
            <div id="alerts-container"><?php exibirAlertas(); ?></div>

            <!-- Botão novo serviço -->
            <div class="d-flex" style="justify-content:flex-end; margin-bottom:16px;">
                <button class="btn btn-success" onclick="abrirModal('modal-servico')">➕ Novo Serviço</button>
            </div>

            <!-- Filtros -->
            <form method="GET" class="filters-bar">
                <div class="form-group">
                    <label>Setor</label>
                    <select name="setor" class="form-control">
                        <option value="">Todos</option>
                        <?php foreach ($setores as $s): ?>
                            <option value="<?= sanitizar($s['setor']) ?>" <?= $filtroSetor === $s['setor'] ? 'selected' : '' ?>>
                                <?= sanitizar($s['setor']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Cargo</label>
                    <select name="cargo" class="form-control">
                        <option value="">Todos</option>
                        <?php foreach ($cargos as $c): ?>
                            <option value="<?= sanitizar($c['cargo']) ?>" <?= $filtroCargo === $c['cargo'] ? 'selected' : '' ?>>
                                <?= sanitizar($c['cargo']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Prioridade</label>
                    <select name="prioridade" class="form-control">
                        <option value="">Todas</option>
                        <option value="urgente" <?= $filtroPrioridade === 'urgente' ? 'selected' : '' ?>>🔴 Urgente</option>
                        <option value="alta"    <?= $filtroPrioridade === 'alta'    ? 'selected' : '' ?>>🟠 Alta</option>
                        <option value="media"   <?= $filtroPrioridade === 'media'   ? 'selected' : '' ?>>🟡 Média</option>
                        <option value="baixa"   <?= $filtroPrioridade === 'baixa'   ? 'selected' : '' ?>>🟢 Baixa</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="">Todos</option>
                        <option value="ativo"     <?= $filtroStatus === 'ativo'     ? 'selected' : '' ?>>Ativo</option>
                        <option value="encerrado" <?= $filtroStatus === 'encerrado' ? 'selected' : '' ?>>Encerrado</option>
                    </select>
                </div>
                <div class="form-group" style="align-self:flex-end;">
                    <button type="submit" class="btn btn-primary">🔍 Filtrar</button>
                    <a href="servicos.php" class="btn btn-secondary">Limpar</a>
                </div>
            </form>

            <!-- Lista de serviços -->
            <?php if (empty($servicos)): ?>
                <div class="panel">
                    <div class="empty-state">
                        <div class="empty-icon">📋</div>
                        <p>Nenhum serviço encontrado.</p>
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($servicos as $s): ?>
                    <div class="panel" style="border-left: 4px solid <?= $s['prioridade'] === 'urgente' ? '#dc3545' : ($s['prioridade'] === 'alta' ? '#fd7e14' : ($s['prioridade'] === 'media' ? '#ffc107' : '#28a745')) ?>;">
                        <div class="panel-header">
                            <div>
                                <h3><?= sanitizar($s['titulo']) ?></h3>
                                <div style="margin-top:4px; display:flex; gap:8px; flex-wrap:wrap;">
                                    <span class="badge <?= $prioridadeBadge[$s['prioridade']] ?>">
                                        <?= ucfirst($s['prioridade']) ?>
                                    </span>
                                    <span class="badge badge-secondary">📁 <?= sanitizar($s['setor']) ?></span>
                                    <?php if ($s['cargo']): ?>
                                        <span class="badge badge-secondary">💼 <?= sanitizar($s['cargo']) ?></span>
                                    <?php endif; ?>
                                    <span class="badge <?= $s['status_geral'] === 'ativo' ? 'badge-success' : 'badge-secondary' ?>">
                                        <?= $s['status_geral'] === 'ativo' ? '✅ Ativo' : '🔒 Encerrado' ?>
                                    </span>
                                </div>
                            </div>
                            <div class="d-flex gap-2">
                                <?php if ($s['status_geral'] === 'ativo'): ?>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="acao"       value="encerrar">
                                        <input type="hidden" name="servico_id" value="<?= $s['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-warning"
                                            onclick="return confirm('Encerrar este serviço?')">🔒 Encerrar</button>
                                    </form>
                                <?php endif; ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="acao"       value="excluir">
                                    <input type="hidden" name="servico_id" value="<?= $s['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger"
                                        onclick="return confirmarExclusao('Excluir este serviço?')">🗑️</button>
                                </form>
                            </div>
                        </div>
                        <div class="panel-body">
                            <?php if ($s['descricao']): ?>
                                <p style="color:#555; margin-bottom:14px;"><?= sanitizar($s['descricao']) ?></p>
                            <?php endif; ?>
                            <p class="text-muted" style="font-size:0.8rem; margin-bottom:12px;">
                                Criado por <?= sanitizar($s['criador_nome']) ?> em <?= date('d/m/Y H:i', strtotime($s['created_at'])) ?>
                            </p>

                            <!-- Status por funcionário -->
                            <?php if (!empty($statusServicos[$s['id']])): ?>
                                <div class="table-responsive">
                                    <table>
                                        <thead>
                                            <tr><th>Funcionário</th><th>Status</th><th>Atualizado em</th></tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($statusServicos[$s['id']] as $ss): ?>
                                                <tr>
                                                    <td><?= sanitizar($ss['nome']) ?></td>
                                                    <td><span class="badge <?= $statusBadge[$ss['status']] ?>"><?= $statusLabel[$ss['status']] ?></span></td>
                                                    <td><?= date('d/m/Y H:i', strtotime($ss['updated_at'])) ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <p class="text-muted">Nenhum funcionário atribuído a este serviço.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal Novo Serviço -->
<div class="modal-overlay" id="modal-servico">
    <div class="modal">
        <div class="modal-header">
            <h4>➕ Novo Serviço</h4>
            <button class="modal-close" onclick="fecharModal('modal-servico')">×</button>
        </div>
        <form method="POST" onsubmit="return validarFormulario('form-servico')" id="form-servico">
            <div class="modal-body">
                <input type="hidden" name="acao" value="criar_servico">
                <div class="form-group">
                    <label>Título *</label>
                    <input type="text" name="titulo" class="form-control" required placeholder="Título do serviço">
                </div>
                <div class="form-group">
                    <label>Descrição</label>
                    <textarea name="descricao" class="form-control" rows="3" placeholder="Descreva o serviço..."></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Setor *</label>
                        <select name="setor" class="form-control" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($setores as $s): ?>
                                <option value="<?= sanitizar($s['setor']) ?>"><?= sanitizar($s['setor']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Cargo (opcional)</label>
                        <select name="cargo" class="form-control">
                            <option value="">Todos do setor</option>
                            <?php foreach ($cargos as $c): ?>
                                <option value="<?= sanitizar($c['cargo']) ?>"><?= sanitizar($c['cargo']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Prioridade</label>
                    <select name="prioridade" class="form-control">
                        <option value="baixa">🟢 Baixa</option>
                        <option value="media" selected>🟡 Média</option>
                        <option value="alta">🟠 Alta</option>
                        <option value="urgente">🔴 Urgente</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modal-servico')">Cancelar</button>
                <button type="submit" class="btn btn-success">💾 Criar Serviço</button>
            </div>
        </form>
    </div>
</div>

<script src="../assets/js/main.js"></script>
</body>
</html>
