<?php
/**
 * Correções de Ponto (Admin)
 * Permite visualizar e corrigir registros de ponto de qualquer funcionário
 */
session_start();
define('BASE_URL', '..');
require_once '../config/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/layout.php';

verificarAdmin();

$adminId = $_SESSION['usuario_id'];

// ---- Filtros de busca ----
$filtroFuncionario = (int)($_GET['funcionario_id'] ?? 0);
$filtroData        = $_GET['data'] ?? date('Y-m-d');

// ---- Processar correção de ponto ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'corrigir') {
    $usuario_id       = (int)$_POST['usuario_id'];
    $data_ref         = $_POST['data_referencia'] ?? '';
    $entrada          = $_POST['entrada']          ?: null;
    $saida            = $_POST['saida']            ?: null;
    $almoco_saida     = $_POST['almoco_saida']     ?: null;
    $almoco_retorno   = $_POST['almoco_retorno']   ?: null;
    $motivo           = trim($_POST['motivo']      ?? '');

    if ($usuario_id && $data_ref && $motivo) {
        // Salva a correção no histórico
        $stmt = $conn->prepare("
            INSERT INTO correcoes_ponto (usuario_id, admin_id, data_referencia, entrada_corrigida, saida_corrigida, almoco_saida_corrigida, almoco_retorno_corrigida, motivo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param('iissssss', $usuario_id, $adminId, $data_ref, $entrada, $saida, $almoco_saida, $almoco_retorno, $motivo);
        $stmt->execute();
        $stmt->close();

        // Atualiza ou insere os registros de ponto corrigidos
        $tipos = [
            'entrada'        => $entrada,
            'saida'          => $saida,
            'almoco_saida'   => $almoco_saida,
            'almoco_retorno' => $almoco_retorno,
        ];

        foreach ($tipos as $tipo => $horario) {
            if ($horario === null) continue;
            $dataHora = $data_ref . ' ' . $horario;

            // Verifica se já existe registro deste tipo neste dia
            $stmtCheck = $conn->prepare("SELECT id FROM registros_ponto WHERE usuario_id=? AND tipo=? AND data_referencia=?");
            $stmtCheck->bind_param('iss', $usuario_id, $tipo, $data_ref);
            $stmtCheck->execute();
            $existe = $stmtCheck->get_result()->fetch_assoc();
            $stmtCheck->close();

            if ($existe) {
                // Atualiza o registro existente
                $stmtUp = $conn->prepare("UPDATE registros_ponto SET data_hora=?, observacao='Corrigido pelo admin' WHERE id=?");
                $stmtUp->bind_param('si', $dataHora, $existe['id']);
                $stmtUp->execute();
                $stmtUp->close();
            } else {
                // Insere novo registro
                $obs = 'Inserido pelo admin';
                $stmtIns = $conn->prepare("INSERT INTO registros_ponto (usuario_id, tipo, data_hora, data_referencia, observacao) VALUES (?,?,?,?,?)");
                $stmtIns->bind_param('issss', $usuario_id, $tipo, $dataHora, $data_ref, $obs);
                $stmtIns->execute();
                $stmtIns->close();
            }
        }

        $_SESSION['msg_sucesso'] = 'Ponto corrigido com sucesso!';
        header("Location: correcoes.php?data=$data_ref&funcionario_id=$usuario_id");
        exit;
    } else {
        $_SESSION['msg_erro'] = 'Preencha todos os campos obrigatórios (funcionário, data e motivo).';
    }
}

// ---- Lista todos os funcionários para o filtro ----
$funcionarios = $conn->query("SELECT id, nome, setor, cargo FROM usuarios WHERE tipo='funcionario' ORDER BY nome")->fetch_all(MYSQLI_ASSOC);

// ---- Busca registros de ponto do dia/funcionário selecionado ----
$registrosDia = [];
if ($filtroData) {
    $sql = "
        SELECT u.id as usuario_id, u.nome, u.setor, u.cargo,
            MAX(CASE WHEN rp.tipo='entrada'        THEN TIME(rp.data_hora) END) as entrada,
            MAX(CASE WHEN rp.tipo='saida'          THEN TIME(rp.data_hora) END) as saida,
            MAX(CASE WHEN rp.tipo='almoco_saida'   THEN TIME(rp.data_hora) END) as almoco_saida,
            MAX(CASE WHEN rp.tipo='almoco_retorno' THEN TIME(rp.data_hora) END) as almoco_retorno,
            MAX(CASE WHEN rp.observacao LIKE '%admin%' THEN 1 ELSE 0 END) as corrigido
        FROM usuarios u
        LEFT JOIN registros_ponto rp ON rp.usuario_id = u.id AND rp.data_referencia = ?
        WHERE u.tipo = 'funcionario'
    ";
    $params = [$filtroData];
    $types  = 's';

    if ($filtroFuncionario > 0) {
        $sql .= " AND u.id = ?";
        $params[] = $filtroFuncionario;
        $types   .= 'i';
    }
    $sql .= " GROUP BY u.id ORDER BY u.nome";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $registrosDia = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

// ---- Histórico de correções ----
$historico = $conn->query("
    SELECT cp.*, u.nome as funcionario_nome, a.nome as admin_nome
    FROM correcoes_ponto cp
    INNER JOIN usuarios u ON u.id = cp.usuario_id
    INNER JOIN usuarios a ON a.id = cp.admin_id
    ORDER BY cp.created_at DESC
    LIMIT 30
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Correções de Ponto - Sistema RH</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="wrapper">
    <?php renderSidebarAdmin('correcoes'); ?>

    <div class="main-content">
        <?php renderTopbar('Correções de Ponto'); ?>

        <div class="content">
            <div id="alerts-container"><?php exibirAlertas(); ?></div>

            <!-- Filtros -->
            <div class="panel">
                <div class="panel-header"><h3>🔍 Filtrar Registros</h3></div>
                <div class="panel-body">
                    <form method="GET" class="filters-bar" style="padding:0; background:none;">
                        <div class="form-group">
                            <label>Funcionário</label>
                            <select name="funcionario_id" class="form-control">
                                <option value="0">Todos</option>
                                <?php foreach ($funcionarios as $f): ?>
                                    <option value="<?= $f['id'] ?>" <?= $filtroFuncionario == $f['id'] ? 'selected' : '' ?>>
                                        <?= sanitizar($f['nome']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Data</label>
                            <input type="date" name="data" class="form-control" value="<?= sanitizar($filtroData) ?>">
                        </div>
                        <div class="form-group" style="align-self:flex-end;">
                            <button type="submit" class="btn btn-primary">🔍 Filtrar</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Registros do dia -->
            <div class="panel">
                <div class="panel-header">
                    <h3>📅 Registros de <?= date('d/m/Y', strtotime($filtroData)) ?></h3>
                    <button class="btn btn-sm btn-warning" onclick="abrirModal('modal-correcao')">✏️ Nova Correção</button>
                </div>
                <?php if (empty($registrosDia)): ?>
                    <div class="empty-state">
                        <div class="empty-icon">📭</div>
                        <p>Nenhum registro encontrado para este filtro.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Funcionário</th>
                                    <th>Setor / Cargo</th>
                                    <th>Entrada</th>
                                    <th>Saída Almoço</th>
                                    <th>Retorno Almoço</th>
                                    <th>Saída</th>
                                    <th>Total Horas</th>
                                    <th>Ação</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($registrosDia as $reg): ?>
                                    <?php $horas = calcularHorasTrabalhadas($reg['entrada'], $reg['saida'], $reg['almoco_saida'], $reg['almoco_retorno']); ?>
                                    <tr>
                                        <td>
                                            <strong><?= sanitizar($reg['nome']) ?></strong>
                                            <?php if ($reg['corrigido']): ?>
                                                <span class="icon-corrected" title="Registro corrigido pelo admin">✏️</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= sanitizar($reg['setor']) ?> / <?= sanitizar($reg['cargo']) ?></td>
                                        <td class="text-success fw-bold"><?= $reg['entrada']        ? substr($reg['entrada'], 0, 5)        : '—' ?></td>
                                        <td class="text-warning"><?= $reg['almoco_saida']   ? substr($reg['almoco_saida'], 0, 5)   : '—' ?></td>
                                        <td class="text-warning"><?= $reg['almoco_retorno'] ? substr($reg['almoco_retorno'], 0, 5) : '—' ?></td>
                                        <td class="text-danger fw-bold"><?= $reg['saida']          ? substr($reg['saida'], 0, 5)          : '—' ?></td>
                                        <td><span class="badge badge-primary"><?= $horas ?></span></td>
                                        <td>
                                            <button class="btn btn-sm btn-warning"
                                                onclick="preencherCorrecao(<?= $reg['usuario_id'] ?>, '<?= sanitizar($reg['nome']) ?>', '<?= $filtroData ?>', '<?= $reg['entrada'] ?: '' ?>', '<?= $reg['saida'] ?: '' ?>', '<?= $reg['almoco_saida'] ?: '' ?>', '<?= $reg['almoco_retorno'] ?: '' ?>')">
                                                ✏️ Corrigir
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Histórico de correções -->
            <div class="panel">
                <div class="panel-header"><h3>📜 Histórico de Correções (últimas 30)</h3></div>
                <?php if (empty($historico)): ?>
                    <div class="empty-state">
                        <div class="empty-icon">📭</div>
                        <p>Nenhuma correção realizada ainda.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Data Ref.</th>
                                    <th>Funcionário</th>
                                    <th>Entrada</th>
                                    <th>Saída</th>
                                    <th>Almoço S.</th>
                                    <th>Almoço R.</th>
                                    <th>Motivo</th>
                                    <th>Admin</th>
                                    <th>Realizado em</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($historico as $h): ?>
                                    <tr>
                                        <td><?= date('d/m/Y', strtotime($h['data_referencia'])) ?></td>
                                        <td><?= sanitizar($h['funcionario_nome']) ?></td>
                                        <td><?= $h['entrada_corrigida']        ? substr($h['entrada_corrigida'], 0, 5)        : '—' ?></td>
                                        <td><?= $h['saida_corrigida']          ? substr($h['saida_corrigida'], 0, 5)          : '—' ?></td>
                                        <td><?= $h['almoco_saida_corrigida']   ? substr($h['almoco_saida_corrigida'], 0, 5)   : '—' ?></td>
                                        <td><?= $h['almoco_retorno_corrigida'] ? substr($h['almoco_retorno_corrigida'], 0, 5) : '—' ?></td>
                                        <td><?= sanitizar($h['motivo']) ?></td>
                                        <td><?= sanitizar($h['admin_nome']) ?></td>
                                        <td><?= date('d/m/Y H:i', strtotime($h['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Correção -->
<div class="modal-overlay" id="modal-correcao">
    <div class="modal">
        <div class="modal-header">
            <h4>✏️ Corrigir Ponto</h4>
            <button class="modal-close" onclick="fecharModal('modal-correcao')">×</button>
        </div>
        <form method="POST">
            <div class="modal-body">
                <input type="hidden" name="acao" value="corrigir">
                <div class="form-row">
                    <div class="form-group">
                        <label>Funcionário *</label>
                        <select name="usuario_id" id="c_usuario" class="form-control" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($funcionarios as $f): ?>
                                <option value="<?= $f['id'] ?>"><?= sanitizar($f['nome']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Data de Referência *</label>
                        <input type="date" name="data_referencia" id="c_data" class="form-control" required value="<?= $filtroData ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>🟢 Entrada</label>
                        <input type="time" name="entrada" id="c_entrada" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>🟡 Saída Almoço</label>
                        <input type="time" name="almoco_saida" id="c_almoco_saida" class="form-control">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>🟡 Retorno Almoço</label>
                        <input type="time" name="almoco_retorno" id="c_almoco_retorno" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>🔴 Saída</label>
                        <input type="time" name="saida" id="c_saida" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label>Motivo da Correção *</label>
                    <textarea name="motivo" id="c_motivo" class="form-control" rows="3" required placeholder="Descreva o motivo da correção..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modal-correcao')">Cancelar</button>
                <button type="submit" class="btn btn-warning">✏️ Salvar Correção</button>
            </div>
        </form>
    </div>
</div>

<script src="../assets/js/main.js"></script>
<script>
function preencherCorrecao(userId, nome, data, entrada, saida, almocoSaida, almocoRetorno) {
    document.getElementById('c_usuario').value         = userId;
    document.getElementById('c_data').value            = data;
    document.getElementById('c_entrada').value         = entrada        ? entrada.substring(0,5)        : '';
    document.getElementById('c_saida').value           = saida          ? saida.substring(0,5)          : '';
    document.getElementById('c_almoco_saida').value    = almocoSaida    ? almocoSaida.substring(0,5)    : '';
    document.getElementById('c_almoco_retorno').value  = almocoRetorno  ? almocoRetorno.substring(0,5)  : '';
    document.getElementById('c_motivo').value          = '';
    abrirModal('modal-correcao');
}
</script>
</body>
</html>
